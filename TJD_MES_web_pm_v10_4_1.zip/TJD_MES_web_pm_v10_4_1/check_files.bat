@echo off
setlocal
cd /d "%~dp0"
echo ================================================================
echo TJD MES Web - File Check
echo ================================================================
for %%F in (server.py mes_core.py web_ui.py pm_module.py start_server.bat) do (
  if exist "%%F" (echo [OK] %%F) else (echo [MISSING] %%F)
)
echo.
if exist "pm_config.json" (echo [OK] pm_config.json - PM mapping saved) else (echo [INFO] pm_config.json - will be created after DB mapping)
echo.
where py >nul 2>nul && echo [OK] py launcher found
where python >nul 2>nul && echo [OK] python found
echo.
pause
