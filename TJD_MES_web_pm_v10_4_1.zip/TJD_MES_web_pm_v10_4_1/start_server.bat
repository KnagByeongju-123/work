@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title TJD MES Web Server

set "PORT=8000"
set "PYTHONUTF8=1"

if not exist "server.py" goto NO_SERVER
if not exist "mes_core.py" goto NO_CORE
if not exist "web_ui.py" goto NO_UI
if not exist "pm_module.py" goto NO_PM

where py >nul 2>nul
if not errorlevel 1 (
    set "PY=py -3"
    goto PY_OK
)

where python >nul 2>nul
if errorlevel 1 goto NO_PYTHON
set "PY=python"

:PY_OK
%PY% -c "import oracledb, openpyxl" >nul 2>nul
if errorlevel 1 (
    echo Installing required Python modules...
    %PY% -m pip install --disable-pip-version-check oracledb openpyxl
    if errorlevel 1 goto PIP_FAIL
)

net session >nul 2>nul
if errorlevel 1 goto START_SERVER
netsh advfirewall firewall delete rule name="TJD MES Web Server" >nul 2>nul
netsh advfirewall firewall add rule name="TJD MES Web Server" ^
    dir=in action=allow protocol=TCP localport=%PORT% ^
    remoteip=localsubnet profile=any >nul 2>nul

:START_SERVER
cls
echo ================================================================
echo  TJD MES Web Server + Preventive Maintenance
echo  Port: %PORT%
echo  Browser UI source: web_ui.py
echo  PM module: pm_module.py
echo  External index.html is NOT required.
echo ================================================================
echo.
%PY% "server.py" %PORT%
set "RC=%ERRORLEVEL%"
echo.
echo Server stopped. Exit code: %RC%
pause
exit /b %RC%

:NO_SERVER
echo [ERROR] server.py was not found.
pause
exit /b 1
:NO_CORE
echo [ERROR] mes_core.py was not found.
pause
exit /b 1
:NO_UI
echo [ERROR] web_ui.py was not found.
pause
exit /b 1
:NO_PM
echo [ERROR] pm_module.py was not found.
pause
exit /b 1
:NO_PYTHON
echo [ERROR] Python 3 was not found.
pause
exit /b 1
:PIP_FAIL
echo [ERROR] Failed to install required Python modules.
pause
exit /b 1
