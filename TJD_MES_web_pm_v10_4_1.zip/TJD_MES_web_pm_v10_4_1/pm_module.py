# -*- coding: utf-8 -*-
"""
태진다이텍 MES - 자주보전/예방점검 연동 모듈

목적
- 기존 Oracle MES의 자주보전(예방점검 주기) 테이블을 직접 사용
- 주기/설명/승인 값 수정
- 누적타발수 >= 점검주기이면 점검도래
- 점검완료 시 기존 점검이력 테이블 INSERT + 주기 테이블 누적타발수 0 + 점검일 갱신
- 위 작업은 하나의 Oracle 트랜잭션으로 COMMIT/ROLLBACK

중요
- 실제 MES 테이블명/컬럼명은 회사 DB마다 다르므로 임의로 가정하지 않습니다.
- 최초 1회 웹 화면 [자주보전관리] > [DB 연결설정]에서 Oracle 구조를 자동검색한 뒤
  추천 매핑을 확인하고 저장합니다.
"""

import os
import re
import json
import csv
import random
import threading
import datetime as dt

ID_RE = re.compile(r"^[A-Z_][A-Z0-9_$#]*$")
TABLE_RE = re.compile(r"^(?:[A-Z_][A-Z0-9_$#]*\.)?[A-Z_][A-Z0-9_$#]*$")
RID_RE = re.compile(r"^[A-Za-z0-9+/=]+$")

# 기존 MES 화면의 점검주기와 코드 대응
CHECK_TYPE_LABELS = {
    "C": "세척",
    "N": "연마",
    "R": "수리",
    "U": "부품교체",
    "W": "정기보전",
}

SCHEDULE_FIELDS = [
    ("mold_code",    "금형코드",       True),
    ("mold_name",    "품명(금형)",     False),
    ("check_type",   "점검유형",       True),
    ("cycle",        "점검주기",       True),
    ("cumulative",   "누적타발수",     True),
    ("approval",     "승인YN",         False),
    ("check_date",   "최근 점검일자",  False),
    ("description",  "설명",           False),
    ("org_id",       "조직ID",         False),
    ("created_at",   "등록일자",       False),
    ("created_by",   "등록자",         False),
    ("updated_at",   "최종수정일자",   False),
    ("updated_by",   "최종수정자",     False),
]

HISTORY_FIELDS = [
    ("mold_code",    "금형코드",       True),
    ("mold_name",    "품명(금형)",     False),
    ("check_type",   "점검유형",       True),
    ("cycle",        "점검주기",       True),
    ("check_date",   "점검일자",       True),
    ("cumulative",   "누적타발수",     True),
    ("description",  "설명",           False),
    ("approval",     "승인YN",         False),
    ("org_id",       "조직ID",         False),
    ("created_at",   "등록일자",       False),
    ("created_by",   "등록자",         False),
    ("updated_at",   "최종수정일자",   False),
    ("updated_by",   "최종수정자",     False),
]

ALIASES = {
    "mold_code": [
        "MOLD_CODE", "MOLD_CD", "MOLD_NO", "DIE_CODE", "DIE_CD", "TOOL_CODE", "TOOL_CD",
        "금형코드", "금형 CODE", "금형번호"
    ],
    "mold_name": [
        "MOLD_NAME", "MOLD_NM", "DIE_NAME", "DIE_NM", "TOOL_NAME", "ITEM_NAME", "ITEM_NM",
        "품명(금형)", "금형명", "품명"
    ],
    "check_type": [
        "CHECK_TYPE", "CHECK_KIND", "INSPECT_TYPE", "INSPECTION_TYPE", "PM_TYPE",
        "MAINT_TYPE", "MAINTENANCE_TYPE", "CHECK_GUBUN", "CHECK_DIV",
        "점검유형", "점검구분", "보전유형"
    ],
    "cycle": [
        "CHECK_CYCLE", "CHECK_PERIOD", "INSPECT_CYCLE", "INSPECTION_CYCLE",
        "MAINT_CYCLE", "PM_CYCLE", "CYCLE", "INTERVAL", "SHOT_CYCLE", "CHECK_SHOT",
        "점검주기", "보전주기", "주기"
    ],
    "cumulative": [
        "CUM_SHOT", "CUMULATIVE_SHOT", "ACC_SHOT", "ACCUM_SHOT", "SHOT_COUNT", "SHOT_CNT",
        "CURRENT_SHOT", "NOW_SHOT", "CHECK_SHOT_QTY", "SHOT_QTY", "HIT_COUNT", "HIT_CNT",
        "누적타발수", "누적타수", "타발수", "SHOT"
    ],
    "approval": [
        "APPROVAL_YN", "APPROVE_YN", "APPR_YN", "CONFIRM_YN", "USE_YN",
        "승인YN", "승인여부", "승인"
    ],
    "check_date": [
        "CHECK_DATE", "CHECK_DT", "INSPECT_DATE", "INSPECTION_DATE", "MAINT_DATE",
        "PM_DATE", "LAST_CHECK_DATE", "LAST_MAINT_DATE",
        "점검일자", "점검일", "최근점검일자"
    ],
    "description": [
        "DESCRIPTION", "DESC", "REMARK", "REMARKS", "MEMO", "NOTE", "COMMENTS",
        "CHECK_DESC", "MAINT_DESC", "설명", "비고", "내용", "점검내용"
    ],
    "org_id": [
        "ORGANIZATION_ID", "ORG_ID", "ORGANIZATION_CODE", "ORG_CODE", "PLANT_ID",
        "SITE_ID", "COMPANY_ID", "조직ID", "조직코드"
    ],
    "created_at": [
        "CREATED_AT", "CREATE_DATE", "CREATION_DATE", "REG_DATE", "REG_DT",
        "INSERT_DATE", "ENTER_DATE", "등록일자", "등록일", "생성일자"
    ],
    "created_by": [
        "CREATED_BY", "CREATE_USER", "REG_USER", "REG_BY", "INSERT_USER",
        "ENTER_USER", "등록자", "등록인"
    ],
    "updated_at": [
        "UPDATED_AT", "UPDATE_DATE", "LAST_UPDATE_DATE", "MODIFY_DATE", "MOD_DATE",
        "최종수정일자", "수정일자", "수정일"
    ],
    "updated_by": [
        "UPDATED_BY", "UPDATE_USER", "LAST_UPDATED_BY", "MODIFY_USER", "MOD_USER",
        "최종수정자", "수정자"
    ],
}

TABLE_SCHEDULE_WORDS = [
    "MOLD", "DIE", "TOOL", "CHECK", "INSPECT", "MAINT", "PM", "PREVENT",
    "금형", "점검", "예방", "보전", "주기"
]
PM_AUDIT_COLS = [
    "처리일시", "작업자", "처리구분", "금형코드", "금형명", "점검유형",
    "점검주기", "누적타발수", "진행률", "담당자", "변경전", "변경후", "설명"
]

TABLE_HISTORY_WORDS = [
    "MOLD", "DIE", "TOOL", "CHECK", "INSPECT", "MAINT", "PM", "HIST", "HISTORY", "LOG",
    "금형", "점검", "예방", "보전", "이력"
]


class PMService:
    def __init__(self, app, cfg, mes, core, user_error, base_dir):
        self.app = app
        self.cfg_main = cfg
        self.mes = mes
        self.core = core
        self.UserError = user_error
        self.base_dir = base_dir
        self.path = os.path.join(base_dir, "pm_config.json")
        self.audit_path = os.path.join(base_dir, "pm_audit_log.csv")
        self.assignment_path = os.path.join(base_dir, "pm_assignment.json")
        self.pending_path = os.path.join(base_dir, "pm_pending_confirm.json")
        self.lock = threading.RLock()
        self.cfg = self._load()

    # ---------------------------------------------------------------
    # config
    # ---------------------------------------------------------------
    def _default(self):
        return {
            "owner": (self.cfg_main.get("schema") or getattr(self.core, "DB_USER", "") or "").upper(),
            "schedule_table": "",
            "history_table": "",
            "schedule_cols": {},
            "history_cols": {},
            "warning_pct": 90,
            "poll_seconds": 60,
            "refresh_seconds": 300,
            "popup_enabled": True,
            "auto_assign_enabled": False,
            "auto_assign_threshold": 90,
            "auto_assignees": [],
            "screen_show_process_type": False,
            "pdf_show_process_type": False,
        }

    def _load(self):
        d = self._default()
        try:
            if os.path.exists(self.path):
                with open(self.path, encoding="utf-8") as f:
                    x = json.load(f)
                if isinstance(x, dict):
                    d.update(x)
        except Exception:
            pass
        d["schedule_cols"] = dict(d.get("schedule_cols") or {})
        d["history_cols"] = dict(d.get("history_cols") or {})
        aa = []
        for x in (d.get("auto_assignees") or []):
            name = str(x or "").strip()[:50]
            if name and name not in aa:
                aa.append(name)
            if len(aa) >= 30:
                break
        d["auto_assignees"] = aa
        return d

    def _save(self):
        with self.lock:
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump(self.cfg, f, ensure_ascii=False, indent=2)

    def info(self):
        return {
            "configured": self.is_configured(),
            "config": self.public_config(),
            "schedule_fields": [list(x) for x in SCHEDULE_FIELDS],
            "history_fields": [list(x) for x in HISTORY_FIELDS],
            "check_type_labels": dict(CHECK_TYPE_LABELS),
            "config_path": self.path,
        }

    def public_config(self):
        return {
            "owner": self.cfg.get("owner") or "",
            "schedule_table": self.cfg.get("schedule_table") or "",
            "history_table": self.cfg.get("history_table") or "",
            "schedule_cols": dict(self.cfg.get("schedule_cols") or {}),
            "history_cols": dict(self.cfg.get("history_cols") or {}),
            "warning_pct": int(self.cfg.get("warning_pct") or 90),
            "poll_seconds": int(self.cfg.get("poll_seconds") or 60),
            "refresh_seconds": int(self.cfg.get("refresh_seconds") or 300),
            "popup_enabled": self.cfg.get("popup_enabled", True) is not False,
            "auto_assign_enabled": self.cfg.get("auto_assign_enabled", False) is True,
            "auto_assign_threshold": int(self.cfg.get("auto_assign_threshold") or 90),
            "auto_assignees": list(self.cfg.get("auto_assignees") or []),
            "screen_show_process_type": self.cfg.get("screen_show_process_type", False) is True,
            "pdf_show_process_type": self.cfg.get("pdf_show_process_type", False) is True,
        }

    def is_configured(self):
        sc = self.cfg.get("schedule_cols") or {}
        hc = self.cfg.get("history_cols") or {}
        return bool(
            self.cfg.get("schedule_table") and self.cfg.get("history_table")
            and all(sc.get(k) for k, _l, req in SCHEDULE_FIELDS if req)
            and all(hc.get(k) for k, _l, req in HISTORY_FIELDS if req)
        )

    # ---------------------------------------------------------------
    # local PM audit / automatic assignee allocation
    # ---------------------------------------------------------------
    def _assignees(self):
        out = []
        for name in self.cfg.get("auto_assignees") or []:
            name = str(name or "").strip()
            if name and name not in out:
                out.append(name[:50])
        return out[:30]

    def _append_audit(self, *, actor="", process_type="", mold_code="", mold_name="",
                      check_type="", cycle="", cumulative="", progress="", assignee="",
                      before="", after="", description=""):
        row = [
            dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), str(actor or "")[:50],
            str(process_type or "")[:30], self.core.show(mold_code), self.core.show(mold_name),
            str(check_type or "").strip().upper(), self.core.show(cycle), self.core.show(cumulative),
            self.core.show(progress), str(assignee or "")[:50], str(before or "")[:1000],
            str(after or "")[:1000], str(description or "")[:1000],
        ]
        try:
            with self.lock:
                new = not os.path.exists(self.audit_path)
                if not new:
                    try:
                        with open(self.audit_path, encoding="utf-8-sig") as f:
                            head = next(csv.reader(f), [])
                        if head != PM_AUDIT_COLS:
                            os.replace(self.audit_path, self.audit_path.replace(".csv", "_old.csv"))
                            new = True
                    except Exception:
                        new = True
                with open(self.audit_path, "a", newline="", encoding="utf-8-sig") as f:
                    w = csv.writer(f)
                    if new:
                        w.writerow(PM_AUDIT_COLS)
                    w.writerow(row)
        except Exception:
            # 감사로그 실패가 MES 트랜잭션 자체를 막지 않도록 합니다.
            pass

    def _audit_process_map(self):
        """Oracle 점검이력과 로컬 감사로그를 연결해 처리구분 표시용 맵을 만듭니다."""
        out = {}
        if not os.path.exists(self.audit_path):
            return out
        try:
            with open(self.audit_path, encoding="utf-8-sig") as f:
                for r in csv.DictReader(f):
                    proc = str(r.get("처리구분") or "").strip()
                    if proc not in ("점검완료", "일괄확정"):
                        continue
                    day = str(r.get("처리일시") or "")[:10]
                    mold = str(r.get("금형코드") or "").strip().upper()
                    ctype = str(r.get("점검유형") or "").strip().upper()
                    try:
                        cyc = round(float(str(r.get("점검주기") or 0).replace(",", "")), 6)
                    except Exception:
                        cyc = 0.0
                    try:
                        cum = round(float(str(r.get("누적타발수") or 0).replace(",", "")), 6)
                    except Exception:
                        cum = 0.0
                    out[(day, mold, ctype, cyc, cum)] = proc
        except Exception:
            pass
        return out

    def _load_assignments(self):
        try:
            if os.path.exists(self.assignment_path):
                with open(self.assignment_path, encoding="utf-8") as f:
                    x = json.load(f)
                if isinstance(x, dict):
                    return x
        except Exception:
            pass
        return {}

    def _save_assignments(self, data):
        tmp = self.assignment_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, self.assignment_path)

    def _load_pending(self):
        try:
            if os.path.exists(self.pending_path):
                with open(self.pending_path, encoding="utf-8") as f:
                    x = json.load(f)
                if isinstance(x, dict):
                    return x
        except Exception:
            pass
        return {}

    def _save_pending(self, data):
        tmp = self.pending_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, self.pending_path)

    @staticmethod
    def _assignment_key(mold_code, check_type, cycle):
        try:
            cyc = f"{float(cycle):.6f}".rstrip("0").rstrip(".")
        except Exception:
            cyc = str(cycle or "")
        return f"{str(mold_code or '').strip().upper()}|{str(check_type or '').strip().upper()}|{cyc}"

    def _assignment_counts(self, names):
        counts = {n: 0 for n in names}
        if not names or not os.path.exists(self.audit_path):
            return counts
        try:
            with open(self.audit_path, encoding="utf-8-sig") as f:
                for r in csv.DictReader(f):
                    if r.get("처리구분") == "자동배정" and r.get("담당자") in counts:
                        counts[r.get("담당자")] += 1
        except Exception:
            pass
        return counts

    def _pick_balanced_assignee(self, names):
        counts = self._assignment_counts(names)
        low = min(counts.values()) if counts else 0
        pool = [n for n in names if counts.get(n, 0) == low]
        return random.choice(pool or names)

    def assignment_for(self, mold_code, check_type, cycle):
        key = self._assignment_key(mold_code, check_type, cycle)
        with self.lock:
            return dict(self._load_assignments().get(key) or {})

    def auto_assign(self, body=None):
        """
        주의구간(기본 90% 이상)에 들어온 점검항목에 담당자를 자동 배정하고
        '일괄확정 대기' 항목을 로컬 파일에 준비합니다.

        이 단계에서는 Oracle 점검이력 INSERT나 누적타발수 초기화를 하지 않습니다.
        실제 MES 반영은 사용자가 [당일점검 일괄확정]에서 최종 확정할 때 수행합니다.
        """
        if not self.is_configured():
            return {"configured": False, "assigned": 0, "prepared": 0, "pending_total": 0, "rows": []}

        enabled = self.cfg.get("auto_assign_enabled", False) is True
        names = self._assignees()
        threshold = max(1, min(99, int(self.cfg.get("auto_assign_threshold") or 90)))
        rows = self.list_rules({}, due_only=False).get("rows") or []
        current_keys = set()
        active_keys = set()
        eligible = []
        for r in rows:
            cyc = self._num(r.get("cycle")); cum = self._num(r.get("cumulative"))
            pct = (cum / cyc * 100.0) if cyc > 0 else 0.0
            key = self._assignment_key(r.get("mold_code"), r.get("check_type"), cyc)
            current_keys.add(key)
            if cyc > 0 and pct >= threshold:
                active_keys.add(key)
                eligible.append((key, r, pct))

        created = []
        prepared = []
        with self.lock:
            data = self._load_assignments()
            pend = self._load_pending()

            # 삭제되었거나 이미 수동 완료되어 임계치 아래로 내려간 항목은 대기목록에서 정리합니다.
            for k in list(data):
                if k not in current_keys or k not in active_keys:
                    data.pop(k, None)
            for k in list(pend):
                if k not in current_keys or k not in active_keys:
                    pend.pop(k, None)

            if enabled and names:
                counts = self._assignment_counts(names)
                for key, r, pct in eligible:
                    rec = data.get(key) or {}
                    who = rec.get("assignee") or ""
                    if not who:
                        low = min(counts.values()) if counts else 0
                        pool = [n for n in names if counts.get(n, 0) == low]
                        who = random.choice(pool or names)
                        counts[who] = counts.get(who, 0) + 1
                        rec = {
                            "assignee": who,
                            "assigned_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "rid": r.get("rid") or "",
                            "mold_code": self.core.show(r.get("mold_code")),
                            "mold_name": self.core.show(r.get("mold_name")),
                            "check_type": str(r.get("check_type") or "").strip().upper(),
                            "cycle": self._num(r.get("cycle")),
                            "cumulative": self._num(r.get("cumulative")),
                            "progress": round(pct, 1),
                        }
                        data[key] = rec
                        created.append(rec)
                    else:
                        # ROWID/현재수치가 바뀌어도 최종확정 시 최신 행을 찾을 수 있게 갱신합니다.
                        rec["rid"] = r.get("rid") or rec.get("rid") or ""
                        rec["cumulative"] = self._num(r.get("cumulative"))
                        rec["progress"] = round(pct, 1)
                        data[key] = rec

                    if key not in pend:
                        pr = {
                            "key": key,
                            "status": "pending",
                            "prepared_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "planned_date": dt.date.today().isoformat(),
                            "rid": r.get("rid") or "",
                            "mold_code": self.core.show(r.get("mold_code")),
                            "mold_name": self.core.show(r.get("mold_name")),
                            "check_type": str(r.get("check_type") or "").strip().upper(),
                            "cycle": self._num(r.get("cycle")),
                            "cumulative": self._num(r.get("cumulative")),
                            "progress": round(pct, 1),
                            "assignee": who,
                        }
                        pend[key] = pr
                        prepared.append(pr)
                    else:
                        pr = pend[key]
                        pr.update({
                            "rid": r.get("rid") or pr.get("rid") or "",
                            "mold_name": self.core.show(r.get("mold_name")) or pr.get("mold_name") or "",
                            "cumulative": self._num(r.get("cumulative")),
                            "progress": round(pct, 1),
                            "assignee": who or pr.get("assignee") or "",
                        })
                        pend[key] = pr

            self._save_assignments(data)
            self._save_pending(pend)
            pending_total = len(pend)

        for rec in created:
            self._append_audit(
                actor="SYSTEM", process_type="자동배정", mold_code=rec.get("mold_code"),
                mold_name=rec.get("mold_name"), check_type=rec.get("check_type"),
                cycle=rec.get("cycle"), cumulative=rec.get("cumulative"), progress=rec.get("progress"),
                assignee=rec.get("assignee"), after=f"담당자={rec.get('assignee')}",
                description=f"진행률 {rec.get('progress')}% 도달 자동 담당자 배정"
            )
        return {
            "configured": True, "enabled": enabled, "assigned": len(created),
            "prepared": len(prepared), "pending_total": pending_total, "rows": created
        }

    def pending_list(self, body=None):
        """일괄확정 대기건 조회. 기본은 오늘 + 이전 미확정 이월건 포함."""
        self._need_config()
        body = body or {}
        target = str(body.get("target_date") or dt.date.today().isoformat()).strip()[:10]
        include_carryover = body.get("include_carryover", True) is not False
        # 최신 누적타발/ROWID와 대기목록을 맞춥니다.
        try:
            self.auto_assign({})
        except Exception:
            pass
        rules = self.list_rules({}, due_only=False).get("rows") or []
        current = {
            self._assignment_key(r.get("mold_code"), r.get("check_type"), r.get("cycle")): r
            for r in rules
        }
        with self.lock:
            pend = self._load_pending()
        out = []
        for key, pr0 in pend.items():
            pr = dict(pr0 or {})
            day = str(pr.get("planned_date") or pr.get("prepared_at") or "")[:10]
            if target:
                if include_carryover:
                    if day and day > target:
                        continue
                elif day != target:
                    continue
            r = current.get(key) or {}
            if not r:
                continue
            cyc = self._num(r.get("cycle")); cum = self._num(r.get("cumulative"))
            pct = (cum / cyc * 100.0) if cyc > 0 else 0.0
            pr.update({
                "key": key, "rid": r.get("rid") or pr.get("rid") or "",
                "mold_code": self.core.show(r.get("mold_code") or pr.get("mold_code")),
                "mold_name": self.core.show(r.get("mold_name") or pr.get("mold_name")),
                "check_type": str(r.get("check_type") or pr.get("check_type") or "").strip().upper(),
                "check_type_label": CHECK_TYPE_LABELS.get(str(r.get("check_type") or pr.get("check_type") or "").strip().upper(),
                                                          str(r.get("check_type") or pr.get("check_type") or "")),
                "cycle": cyc, "cumulative": cum, "progress": round(pct, 1),
                "assignee": r.get("assignee") or pr.get("assignee") or "",
                "status": "pending",
            })
            out.append(pr)
        out.sort(key=lambda x: (str(x.get("planned_date") or ""), str(x.get("mold_code") or ""), str(x.get("check_type") or "")))
        return {"rows": out, "total": len(out), "target_date": target, "include_carryover": include_carryover}

    def batch_confirm(self, body, user):
        """
        선택한 대기건을 한 번의 최종확정으로 실제 MES에 반영합니다.
        - 담당자 이름으로 점검완료 이력 INSERT
        - 같은 트랜잭션에서 예방점검 누적타발수 0 초기화
        - 전체 건 중 하나라도 실패하면 전부 ROLLBACK
        """
        self._need_config()
        body = body or {}
        keys = []
        for x in (body.get("keys") or []):
            k = str(x or "").strip()
            if k and k not in keys:
                keys.append(k)
        if not keys:
            raise self.UserError("최종확정할 점검건을 선택하세요.")
        confirmer = str(user or "").split("(실행", 1)[0].strip()[:50] or "WEB"
        now = dt.datetime.now()

        with self.lock:
            pend_all = self._load_pending()
            selected = []
            for k in keys:
                pr = dict(pend_all.get(k) or {})
                if not pr:
                    raise self.UserError("일괄확정 대기목록이 변경되었습니다. 다시 조회하세요.")
                pr["key"] = k
                selected.append(pr)

        sm, hm = self.cfg["schedule_cols"], self.cfg["history_cols"]

        def work(conn):
            cur = conn.cursor()
            sched_table = self._table(self.cfg["schedule_table"])
            hist_table = self._table(self.cfg["history_table"])
            hcols = {x["name"] for x in self._schema_columns(conn, self.cfg["history_table"])}
            results = []
            for pr in selected:
                # 키 기준으로 최신 주기 행을 다시 찾고 잠급니다. ROWID가 바뀐 경우도 대응합니다.
                mold = str(pr.get("mold_code") or "").strip()
                ctype = str(pr.get("check_type") or "").strip().upper()
                cycle = self._num(pr.get("cycle"))
                conds = [
                    f"UPPER(TRIM(TO_CHAR(T.{sm['mold_code']})))=UPPER(TRIM(TO_CHAR(:mold)))",
                    f"UPPER(TRIM(TO_CHAR(T.{sm['check_type']})))=UPPER(TRIM(TO_CHAR(:ctype)))",
                    f"NVL(T.{sm['cycle']},0)=:cycle",
                ]
                cur.execute(
                    f"SELECT ROWIDTOCHAR(T.ROWID), T.* FROM {sched_table} T WHERE " + " AND ".join(conds) + " FOR UPDATE",
                    mold=mold, ctype=ctype, cycle=cycle
                )
                row = cur.fetchone()
                if row is None:
                    raise self.UserError(f"{mold} / {CHECK_TYPE_LABELS.get(ctype, ctype)} 점검항목을 찾지 못했습니다. 다시 조회하세요.")
                names = [d[0] for d in cur.description]
                rid = row[0]
                src = dict(zip(names[1:], row[1:]))

                def sv(key):
                    c = sm.get(key)
                    return src.get(c) if c else None

                actual_cycle = self._num(sv("cycle"))
                cumulative = self._num(sv("cumulative"))
                if actual_cycle <= 0:
                    raise self.UserError(f"{mold}의 점검주기가 0이어서 완료할 수 없습니다.")
                if cumulative <= 0:
                    raise self.UserError(f"{mold} / {CHECK_TYPE_LABELS.get(ctype, ctype)}는 이미 누적타발수가 초기화되었습니다. 대기목록을 새로고침하세요.")
                assignee = str(pr.get("assignee") or "").strip()[:50]
                if not assignee:
                    raise self.UserError(f"{mold} / {CHECK_TYPE_LABELS.get(ctype, ctype)} 담당자가 없습니다.")

                vals = {}
                semantic_values = {
                    "mold_code": sv("mold_code"),
                    "mold_name": sv("mold_name"),
                    "check_type": sv("check_type"),
                    "cycle": sv("cycle"),
                    "check_date": now,
                    "cumulative": sv("cumulative"),
                    "description": sv("description") or "자주보전 점검완료",
                    "approval": sv("approval"),
                    "org_id": sv("org_id"),
                    "created_at": now,
                    "created_by": assignee,
                    "updated_at": now,
                    "updated_by": assignee,
                }
                for field, val in semantic_values.items():
                    c = hm.get(field)
                    if c and val is not None:
                        vals[c] = val
                for c, v in src.items():
                    if c in hcols and c not in vals and v is not None:
                        vals[c] = v
                if not vals:
                    raise self.UserError("점검이력에 저장할 컬럼 매핑이 없습니다.")
                cols = list(vals)
                binds = {f"b{i}": vals[c] for i, c in enumerate(cols)}
                cur.execute(
                    f"INSERT INTO {hist_table} ({', '.join(cols)}) VALUES ("
                    + ", ".join(f":b{i}" for i in range(len(cols))) + ")",
                    binds
                )

                sets = [f"{sm['cumulative']}=0"]
                ub = {"rid": rid}
                if sm.get("check_date"):
                    sets.append(f"{sm['check_date']}=:check_dt"); ub["check_dt"] = now
                if sm.get("updated_at"):
                    sets.append(f"{sm['updated_at']}=SYSDATE")
                if sm.get("updated_by"):
                    sets.append(f"{sm['updated_by']}=:upd_user"); ub["upd_user"] = assignee
                cur.execute(f"UPDATE {sched_table} SET {', '.join(sets)} WHERE ROWID=CHARTOROWID(:rid)", ub)
                if cur.rowcount != 1:
                    raise self.UserError(f"{mold} 누적타발수 초기화 대상을 찾지 못했습니다.")

                results.append({
                    "key": pr.get("key"), "mold_code": self.core.show(sv("mold_code")),
                    "mold_name": self.core.show(sv("mold_name")), "check_type": self.core.show(sv("check_type")),
                    "cycle": actual_cycle, "before_cumulative": cumulative, "assignee": assignee,
                    "check_date": now.strftime("%Y-%m-%d %H:%M"),
                })
            conn.commit()
            return results

        results = self.app.run_db(work)

        with self.lock:
            pend = self._load_pending()
            assigns = self._load_assignments()
            for r in results:
                pend.pop(r.get("key"), None)
                assigns.pop(r.get("key"), None)
            self._save_pending(pend)
            self._save_assignments(assigns)

        for r in results:
            cyc = self._num(r.get("cycle")); cum = self._num(r.get("before_cumulative"))
            pct = (cum / cyc * 100.0) if cyc > 0 else 0
            self._append_audit(
                actor=confirmer, process_type="일괄확정", mold_code=r.get("mold_code"), mold_name=r.get("mold_name"),
                check_type=r.get("check_type"), cycle=r.get("cycle"), cumulative=r.get("before_cumulative"),
                progress=round(pct, 1), assignee=r.get("assignee"),
                before=f"누적타발={self.core.show(r.get('before_cumulative'))}", after="점검이력 생성 / 누적타발=0",
                description=f"당일점검 일괄확정 · 확정자 {confirmer}"
            )
        return {"ok": True, "confirmed": len(results), "rows": results, "pending_total": max(0, len(pend))}

    def audit_report(self, body=None):
        body = body or {}
        d1 = str(body.get("date_from") or "").strip()
        d2 = str(body.get("date_to") or "").strip()
        types = {str(x).strip().upper() for x in (body.get("check_types") or []) if str(x).strip()}
        assignee = str(body.get("assignee") or "").strip()
        processes = {str(x).strip() for x in (body.get("process_types") or []) if str(x).strip()}
        out = []
        if os.path.exists(self.audit_path):
            try:
                with open(self.audit_path, encoding="utf-8-sig") as f:
                    for r in csv.DictReader(f):
                        day = str(r.get("처리일시") or "")[:10]
                        if d1 and day < d1: continue
                        if d2 and day > d2: continue
                        if types and str(r.get("점검유형") or "").strip().upper() not in types: continue
                        if assignee and str(r.get("담당자") or "").strip() != assignee: continue
                        if processes and str(r.get("처리구분") or "").strip() not in processes: continue
                        code = str(r.get("점검유형") or "").strip().upper()
                        out.append({
                            "event_at": r.get("처리일시") or "", "actor": r.get("작업자") or "",
                            "process_type": r.get("처리구분") or "", "mold_code": r.get("금형코드") or "",
                            "mold_name": r.get("금형명") or "", "check_type": code,
                            "check_type_label": CHECK_TYPE_LABELS.get(code, code), "cycle": r.get("점검주기") or "",
                            "cumulative": r.get("누적타발수") or "", "progress": r.get("진행률") or "",
                            "assignee": r.get("담당자") or "", "before": r.get("변경전") or "",
                            "after": r.get("변경후") or "", "description": r.get("설명") or "",
                        })
            except Exception:
                out = []
        out.sort(key=lambda x: x.get("event_at") or "")
        return {"rows": out, "total": len(out), "check_type_labels": dict(CHECK_TYPE_LABELS)}

    def history_report(self, body=None):
        self._need_config()
        body = body or {}
        hm = self.cfg["history_cols"]
        d1 = str(body.get("date_from") or "").strip()
        d2 = str(body.get("date_to") or "").strip()
        types = [str(x).strip().upper() for x in (body.get("check_types") or []) if str(x).strip()]
        creator = str(body.get("assignee") or "").strip()
        try:
            start = dt.datetime.strptime(d1, "%Y-%m-%d") if d1 else dt.datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            end = dt.datetime.strptime(d2, "%Y-%m-%d") + dt.timedelta(days=1) if d2 else start + dt.timedelta(days=1)
        except Exception:
            raise self.UserError("조회기간 형식이 올바르지 않습니다.")
        fields = [k for k, _l, _r in HISTORY_FIELDS if hm.get(k)]
        sels = [f"T.{hm[k]}" for k in fields]
        table = self._table(self.cfg["history_table"])
        process_map = self._audit_process_map()

        def work(conn):
            conds = [f"T.{hm['check_date']} >= :d1", f"T.{hm['check_date']} < :d2"]
            binds = {"d1": start, "d2": end}
            master_join = ""
            master_name_expr = ""
            if not hm.get("mold_name") and hm.get("mold_code"):
                try:
                    mt, mc, mn, _ = self._mold_master_info(conn)
                    if mn:
                        master_join = (f" LEFT JOIN {mt} M ON "
                                       f"UPPER(TRIM(TO_CHAR(M.{mc})))=UPPER(TRIM(TO_CHAR(T.{hm['mold_code']})))")
                        master_name_expr = f", M.{mn}"
                except Exception:
                    pass
            if types:
                ph = []
                for i, v in enumerate(types):
                    k = f"t{i}"; ph.append(f":{k}"); binds[k] = v
                conds.append(f"UPPER(TRIM(TO_CHAR(T.{hm['check_type']}))) IN ({', '.join(ph)})")
            if creator and hm.get("created_by"):
                conds.append(f"TRIM(TO_CHAR(T.{hm['created_by']}))=:creator")
                binds["creator"] = creator
            sql = f"SELECT {', '.join(sels)}{master_name_expr} FROM {table} T{master_join} WHERE " + " AND ".join(conds)
            sql += f" ORDER BY T.{hm['check_date']}, T.{hm['mold_code']}"
            cur = conn.cursor(); cur.execute(sql, binds)
            rows = []
            for r in cur.fetchall():
                d = {}
                for i, k in enumerate(fields):
                    v = r[i]
                    d[k] = self.core.show(v) if isinstance(v, (dt.date, dt.datetime)) else v
                if master_name_expr and not d.get("mold_name"):
                    d["mold_name"] = self.core.show(r[len(fields)])
                code = str(d.get("check_type") or "").strip().upper()
                d["check_type"] = code
                d["check_type_label"] = CHECK_TYPE_LABELS.get(code, code)
                d["event_at"] = d.get("check_date") or d.get("created_at") or ""
                d["assignee"] = d.get("created_by") or ""
                day = str(d.get("event_at") or "")[:10]
                try: cyc_key = round(float(d.get("cycle") or 0), 6)
                except Exception: cyc_key = 0.0
                try: cum_key = round(float(d.get("cumulative") or 0), 6)
                except Exception: cum_key = 0.0
                d["process_type"] = process_map.get((day, str(d.get("mold_code") or "").strip().upper(), code, cyc_key, cum_key), "수동")
                rows.append(d)
            return {"rows": rows, "total": len(rows), "check_type_labels": dict(CHECK_TYPE_LABELS)}
        return self.app.run_db(work)

    # ---------------------------------------------------------------
    # identifiers / schema
    # ---------------------------------------------------------------
    def _owner(self):
        o = (self.cfg.get("owner") or self.cfg_main.get("schema") or getattr(self.core, "DB_USER", "") or "").upper().strip()
        if not ID_RE.match(o):
            raise self.UserError("Oracle 스키마(OWNER) 설정이 올바르지 않습니다.")
        return o

    def _table(self, t):
        t = str(t or "").upper().strip()
        if not TABLE_RE.match(t):
            raise self.UserError(f"테이블명이 올바르지 않습니다: {t}")
        return t if "." in t else self._owner() + "." + t

    @staticmethod
    def _col(c):
        c = str(c or "").upper().strip()
        if not c:
            return ""
        if not ID_RE.match(c):
            raise ValueError(f"컬럼명이 올바르지 않습니다: {c}")
        return c

    def _rid(self, rid):
        rid = str(rid or "").strip()
        if not rid or not RID_RE.match(rid):
            raise self.UserError("선택한 점검항목 정보가 올바르지 않습니다. 다시 조회하세요.")
        return rid

    def _table_name_only(self, t):
        return str(t or "").upper().split(".")[-1]

    def _schema_columns(self, conn, table):
        owner = self._owner()
        tname = self._table_name_only(table)
        cur = conn.cursor()
        cur.execute("""
            SELECT C.COLUMN_NAME, C.DATA_TYPE, C.NULLABLE, C.COLUMN_ID, C.DATA_LENGTH,
                   NVL(CC.COMMENTS, '')
              FROM ALL_TAB_COLUMNS C
              LEFT JOIN ALL_COL_COMMENTS CC
                ON CC.OWNER=C.OWNER AND CC.TABLE_NAME=C.TABLE_NAME AND CC.COLUMN_NAME=C.COLUMN_NAME
             WHERE C.OWNER=:o AND C.TABLE_NAME=:t
             ORDER BY C.COLUMN_ID
        """, o=owner, t=tname)
        rows = cur.fetchall()
        if not rows:
            raise self.UserError(f"테이블을 찾을 수 없거나 조회 권한이 없습니다: {owner}.{tname}")
        return [
            {"name": r[0], "type": r[1], "nullable": r[2], "position": r[3],
             "length": r[4] or 0, "comment": (r[5] or "").strip()}
            for r in rows
        ]

    @staticmethod
    def _norm(s):
        return re.sub(r"[\s_\-()/]+", "", str(s or "").upper())

    def _col_score(self, field, col):
        n = self._norm(col["name"])
        c = self._norm(col.get("comment"))
        best = 0
        for a in ALIASES.get(field, []):
            a2 = self._norm(a)
            if not a2:
                continue
            if n == a2:
                best = max(best, 100)
            elif c == a2:
                best = max(best, 95)
            elif a2 in n or n in a2:
                best = max(best, 65)
            elif a2 in c or (c and c in a2):
                best = max(best, 75)
        return best

    def _suggest(self, cols, role):
        fields = SCHEDULE_FIELDS if role == "schedule" else HISTORY_FIELDS
        used = set()
        out = {}
        for field, _label, _req in fields:
            ranked = sorted(
                [(self._col_score(field, c), c["name"]) for c in cols if c["name"] not in used],
                reverse=True,
            )
            if ranked and ranked[0][0] >= 60:
                out[field] = ranked[0][1]
                used.add(ranked[0][1])
        return out

    def _table_scores(self, name, comment, cols):
        ns = self._norm(name + " " + (comment or ""))
        ss = sum(3 for w in TABLE_SCHEDULE_WORDS if self._norm(w) in ns)
        hs = sum(3 for w in TABLE_HISTORY_WORDS if self._norm(w) in ns)
        sm = self._suggest(cols, "schedule")
        hm = self._suggest(cols, "history")
        ss += sum(8 if req and sm.get(k) else 2 if sm.get(k) else 0 for k, _l, req in SCHEDULE_FIELDS)
        hs += sum(8 if req and hm.get(k) else 2 if hm.get(k) else 0 for k, _l, req in HISTORY_FIELDS)
        if any(x in ns for x in ("HIST", "HISTORY", self._norm("이력"))):
            hs += 15
            ss -= 4
        if any(x in ns for x in ("CYCLE", "PERIOD", self._norm("주기"))):
            ss += 12
        return max(0, ss), max(0, hs)

    # ---------------------------------------------------------------
    # discovery / mapping
    # ---------------------------------------------------------------
    def discover(self):
        def work(conn):
            owner = self._owner()
            cur = conn.cursor()
            cur.execute("""
                SELECT C.TABLE_NAME, C.COLUMN_NAME, C.DATA_TYPE, C.NULLABLE, C.COLUMN_ID,
                       NVL(CC.COMMENTS, ''), NVL(TC.COMMENTS, '')
                  FROM ALL_TAB_COLUMNS C
                  JOIN ALL_TABLES T ON T.OWNER=C.OWNER AND T.TABLE_NAME=C.TABLE_NAME
                  LEFT JOIN ALL_COL_COMMENTS CC
                    ON CC.OWNER=C.OWNER AND CC.TABLE_NAME=C.TABLE_NAME AND CC.COLUMN_NAME=C.COLUMN_NAME
                  LEFT JOIN ALL_TAB_COMMENTS TC
                    ON TC.OWNER=C.OWNER AND TC.TABLE_NAME=C.TABLE_NAME
                 WHERE C.OWNER=:o
                 ORDER BY C.TABLE_NAME, C.COLUMN_ID
            """, o=owner)
            grouped = {}
            comments = {}
            for t, col, typ, nul, pos, ccom, tcom in cur.fetchall():
                grouped.setdefault(t, []).append({
                    "name": col, "type": typ, "nullable": nul, "position": pos,
                    "comment": (ccom or "").strip()
                })
                comments[t] = (tcom or "").strip()
            tables = []
            for t, cols in grouped.items():
                ss, hs = self._table_scores(t, comments.get(t), cols)
                tables.append({
                    "table": t, "comment": comments.get(t) or "",
                    "schedule_score": ss, "history_score": hs
                })
            tables.sort(key=lambda x: max(x["schedule_score"], x["history_score"]), reverse=True)
            rec_s = max(tables, key=lambda x: x["schedule_score"], default=None)
            hist_pool = [x for x in tables if not rec_s or x["table"] != rec_s["table"]]
            rec_h = max(hist_pool or tables, key=lambda x: x["history_score"], default=None)
            return {
                "owner": owner,
                "tables": tables,
                "recommended": {
                    "schedule": rec_s["table"] if rec_s else "",
                    "history": rec_h["table"] if rec_h else "",
                },
                "config": self.public_config(),
                "schedule_fields": [list(x) for x in SCHEDULE_FIELDS],
                "history_fields": [list(x) for x in HISTORY_FIELDS],
            }
        return self.app.run_db(work)

    def table_columns(self, body):
        table = str(body.get("table") or "").upper().strip()
        role = body.get("role") if body.get("role") in ("schedule", "history") else "schedule"
        def work(conn):
            cols = self._schema_columns(conn, table)
            return {"table": table, "cols": cols, "suggest": self._suggest(cols, role)}
        return self.app.run_db(work)

    def save_config(self, body):
        owner = str(body.get("owner") or self._owner()).upper().strip()
        if not ID_RE.match(owner):
            raise self.UserError("OWNER(스키마)가 올바르지 않습니다.")
        st = str(body.get("schedule_table") or "").upper().strip()
        ht = str(body.get("history_table") or "").upper().strip()
        sm = {k: self._col(v) for k, v in (body.get("schedule_cols") or {}).items() if v}
        hm = {k: self._col(v) for k, v in (body.get("history_cols") or {}).items() if v}

        for k, label, req in SCHEDULE_FIELDS:
            if req and not sm.get(k):
                raise self.UserError(f"예방점검 주기 테이블의 [{label}] 컬럼을 지정하세요.")
        for k, label, req in HISTORY_FIELDS:
            if req and not hm.get(k):
                raise self.UserError(f"점검이력 테이블의 [{label}] 컬럼을 지정하세요.")

        old_owner = self.cfg.get("owner")
        self.cfg["owner"] = owner
        try:
            def work(conn):
                scols = {c["name"] for c in self._schema_columns(conn, st)}
                hcols = {c["name"] for c in self._schema_columns(conn, ht)}
                bads = [c for c in sm.values() if c not in scols]
                badh = [c for c in hm.values() if c not in hcols]
                if bads:
                    raise self.UserError("주기 테이블에 없는 컬럼: " + ", ".join(bads))
                if badh:
                    raise self.UserError("이력 테이블에 없는 컬럼: " + ", ".join(badh))
                cur = conn.cursor()
                cur.execute(f"SELECT ROWIDTOCHAR(T.ROWID) FROM {self._table(st)} T WHERE ROWNUM<=1")
                cur.execute(f"SELECT ROWIDTOCHAR(T.ROWID) FROM {self._table(ht)} T WHERE ROWNUM<=1")
                return True
            self.app.run_db(work)
        except Exception:
            self.cfg["owner"] = old_owner
            raise

        assignees = []
        for x in (body.get("auto_assignees") or []):
            name = str(x or "").strip()[:50]
            if name and name not in assignees:
                assignees.append(name)
            if len(assignees) >= 30:
                break
        auto_assign_enabled = body.get("auto_assign_enabled", False) is True
        if auto_assign_enabled and not assignees:
            raise self.UserError("자동 담당자 배정을 사용하려면 담당자를 1명 이상 입력하세요.")
        self.cfg.update({
            "owner": owner,
            "schedule_table": st,
            "history_table": ht,
            "schedule_cols": sm,
            "history_cols": hm,
            "warning_pct": max(1, min(100, int(body.get("warning_pct") or 90))),
            "poll_seconds": max(15, min(3600, int(body.get("poll_seconds") or 60))),
            "refresh_seconds": max(60, min(3600, int(body.get("refresh_seconds") or 300))),
            "popup_enabled": body.get("popup_enabled", True) is not False,
            "auto_assign_enabled": auto_assign_enabled,
            "auto_assign_threshold": max(1, min(99, int(body.get("auto_assign_threshold") or 90))),
            "auto_assignees": assignees,
            "screen_show_process_type": body.get("screen_show_process_type", False) is True,
            "pdf_show_process_type": body.get("pdf_show_process_type", False) is True,
        })
        self._save()
        return self.info()

    # ---------------------------------------------------------------
    # common DB helpers
    # ---------------------------------------------------------------
    def _need_config(self):
        if not self.is_configured():
            raise self.UserError("자주보전 DB 연결설정이 아직 완료되지 않았습니다. [DB 연결설정]을 먼저 하세요.")

    @staticmethod
    def _num(v):
        if v is None or v == "":
            return 0.0
        try:
            return float(v)
        except Exception:
            return 0.0

    def _select_parts(self, mapping):
        fields, sqls = [], []
        for k, _label, _req in SCHEDULE_FIELDS:
            c = mapping.get(k)
            if c:
                fields.append(k)
                sqls.append(f"T.{c}")
        return fields, sqls

    def _mold_master_info(self, conn):
        """
        기존 MES 금형마스터에서 금형코드/금형명 및 전체 행을 읽기 위한 정보.
        기존 v7.7 설정의 mold 테이블/매핑을 우선 사용합니다.
        """
        mc = self.cfg_main.get("mold") or {}
        table = self.mes.qualify(mc.get("table") or "ICOM_MOLD")
        code_col = (mc.get("code_col") or "MOLD_CODE").upper()

        # 화면 매핑 중 금형명으로 보이는 컬럼 우선
        name_col = ""
        for c in mc.get("columns") or []:
            col = str(c.get("col") or "").upper()
            nm = str(c.get("name") or "")
            if col and ("금형명" in nm or "품명" in nm or col in ("MOLD_NAME","MOLD_NM","ITEM_NAME")):
                name_col = col
                break

        owner, tname = table.split(".") if "." in table else (self._owner(), table)
        cur = conn.cursor()
        cur.execute("""
            SELECT COLUMN_NAME
              FROM ALL_TAB_COLUMNS
             WHERE OWNER=:o AND TABLE_NAME=:t
        """, o=owner.upper(), t=tname.upper())
        cols = {r[0] for r in cur.fetchall()}
        if code_col not in cols:
            for cand in ("MOLD_CODE","MOLD_CD","MOLD_NO","DIE_CODE","DIE_CD","TOOL_CODE"):
                if cand in cols:
                    code_col = cand
                    break
        if not name_col or name_col not in cols:
            for cand in ("MOLD_NAME","MOLD_NM","ITEM_NAME","ITEM_NM","MOLD_DESC","DESCRIPTION"):
                if cand in cols:
                    name_col = cand
                    break
        return table, code_col, name_col, cols

    def _mold_display_map(self):
        """기존 MES 금형 매핑의 표시이름을 DB컬럼 기준으로 반환."""
        out = {}
        mc = self.cfg_main.get("mold") or {}
        for c in mc.get("columns") or []:
            col = str(c.get("col") or "").upper().strip()
            if col:
                out[col] = str(c.get("name") or col).strip()
        return out

    def _mold_col_comments(self, conn, table):
        owner, tname = table.split(".") if "." in table else (self._owner(), table)
        cur = conn.cursor()
        cur.execute("""
            SELECT COLUMN_NAME, NVL(COMMENTS,'')
              FROM ALL_COL_COMMENTS
             WHERE OWNER=:o AND TABLE_NAME=:t
        """, o=owner.upper(), t=tname.upper())
        return {r[0]: (r[1] or "").strip() for r in cur.fetchall()}

    def _pick_mold_col(self, cols, candidates):
        for c in candidates:
            if c in cols:
                return c
        return ""

    def _pick_mold_col_semantic(self, cols, comments, display, candidates, keywords):
        """
        1) DB 컬럼명 후보
        2) 기존 MES 표시이름
        3) Oracle 컬럼 COMMENT
        순서로 실제 컬럼을 찾습니다.
        """
        c = self._pick_mold_col(cols, candidates)
        if c:
            return c
        for col in cols:
            txt = " ".join([
                str(col or ""),
                str((display or {}).get(col) or ""),
                str((comments or {}).get(col) or "")
            ]).upper().replace(" ", "")
            for kw in keywords:
                if str(kw).upper().replace(" ", "") in txt:
                    return col
        return ""

    def mold_search(self, body):
        """
        자주보전 화면 상단 금형목록.
        원본 MES처럼 금형마스터 정보를 위에 표시하고, 선택한 금형의
        예방점검주기/점검이력을 아래에 표시하기 위한 데이터.
        """
        q = str((body or {}).get("q") or "").strip()
        # 금형마스터는 전체 조회합니다. 기존 버전의 1,500/3,000건 제한을 제거했습니다.
        # 화면 표 자체가 '더 보기' 방식으로 렌더링하므로 전체 행을 받아도 브라우저 부담을 줄일 수 있습니다.

        def work(conn):
            table, code_col, name_col, cols = self._mold_master_info(conn)
            comments = self._mold_col_comments(conn, table)
            display = self._mold_display_map()

            # 원본 MES 화면과 유사한 핵심 컬럼을 자동 탐색
            picks = {
                "mold_code": code_col,
                "mold_name": name_col,
                "mold_spec": self._pick_mold_col_semantic(
                    cols, comments, display,
                    [
                        "MOLD_SPEC", "MOLD_SPECIFICATION", "MOLD_SIZE", "MOLD_STANDARD",
                        "SPEC", "SPECIFICATION", "MOLD_DIMENSION", "DIE_SPEC", "TOOL_SPEC"
                    ],
                    ["금형규격", "금형사양", "MOLD SPEC", "SPECIFICATION"]
                ),
                "mold_status": self._pick_mold_col(cols, [
                    "MOLD_STATUS","MOLD_STATE","STATUS","STATE","USE_STATUS","MOLD_USE_STATUS"
                ]),
                "mold_group": self._pick_mold_col(cols, [
                    "MOLD_GROUP","MOLD_GROUP_CODE","MOLD_GRP","GROUP_CODE","MOLD_TYPE_GROUP"
                ]),
                "drawing_no": self._pick_mold_col(cols, [
                    "DRAWING_NO","DRAW_NO","DWG_NO","DRAWING_NUMBER","DO_NO"
                ]),
                "prod_seq": self._pick_mold_col(cols, [
                    "PROD_SEQ","PRODUCTION_SEQ","PROD_ORDER","SEQ","MOLD_SEQ"
                ]),
                "item_code": self._pick_mold_col(cols, [
                    "ITEM_CODE","ITEM_CD","ITEM_NO","PART_NO","PRODUCT_CODE"
                ]),
                "barcode": self._pick_mold_col(cols, [
                    "BARCODE","BAR_CODE","MOLD_BARCODE"
                ]),
                "mold_type": self._pick_mold_col(cols, [
                    "MOLD_TYPE","MOLD_KIND","TYPE_CODE","MOLD_GUBUN"
                ]),
                "life_limit": self._pick_mold_col(cols, [
                    "LIMIT_LIFE","LIFE_LIMIT","MAX_SHOT","MOLD_LIFE","LIMIT_SHOT","LIFE_SHOT"
                ]),
                "shot": self._pick_mold_col(cols, [
                    "SHOT","SHOT_COUNT","SHOT_CNT","TOTAL_SHOT","ACC_SHOT","CUM_SHOT"
                ]),
                "supplier": self._pick_mold_col(cols, [
                    "SUPPLIER","SUPPLIER_NAME","VENDOR","VENDOR_NAME","SUPPLY_COMPANY"
                ]),
                "purchase_type": self._pick_mold_col(cols, [
                    "PURCHASE_TYPE","PURCHASE_GUBUN","MOLD_PURCHASE_TYPE"
                ]),
                "country_code": self._pick_mold_col(cols, [
                    "COUNTRY_CODE","NATION_CODE","COUNTRY"
                ]),
                "description": self._pick_mold_col(cols, [
                    "DESCRIPTION","DESC","REMARK","REMARKS","NOTE"
                ]),
                "cavity": self._pick_mold_col(cols, [
                    "CAVITY","CAVITY_QTY","CAVITY_COUNT"
                ]),
                "tt": self._pick_mold_col(cols, [
                    "T_T","TT","TACT_TIME","CYCLE_TIME"
                ]),
                "location": self._pick_mold_col(cols, [
                    "MOLD_LOCATION","LOCATION","STORAGE_LOCATION","LOC_CODE"
                ]),
                "version": self._pick_mold_col(cols, [
                    "MOLD_VERSION","VERSION","REVISION","REV"
                ]),
                "serial": self._pick_mold_col(cols, [
                    "MOLD_SERIAL","SERIAL_NO","SERIAL_NUMBER","MOLD_SERIAL_NO"
                ]),
            }

            selected = []
            aliases = []
            for key, col in picks.items():
                if col:
                    selected.append(f"M.{col}")
                    aliases.append(key)

            # searchable columns
            search_cols = [x for x in [
                code_col, name_col, picks["mold_spec"], picks["drawing_no"], picks["item_code"]
            ] if x]
            binds = {}
            where = ""
            if q:
                terms = [f"UPPER(TO_CHAR(M.{c})) LIKE :q" for c in dict.fromkeys(search_cols)]
                if terms:
                    where = " WHERE (" + " OR ".join(terms) + ")"
                    binds["q"] = "%" + q.upper() + "%"

            sql = f"""
                SELECT {', '.join(selected)}
                  FROM {table} M
                  {where}
                 ORDER BY M.{code_col}
            """
            cur = conn.cursor()
            cur.execute(sql, binds)

            sm = self.cfg.get("schedule_cols") or {}
            sched = self._table(self.cfg["schedule_table"]) if self.is_configured() else None
            use_map = self._current_mold_use(conn)

            # 금형별 등록 점검항목 수를 한 번에 읽습니다.
            # 전체 금형 조회 시 금형마다 COUNT 쿼리를 반복하지 않도록 개선했습니다.
            rule_counts = {}
            due_counts = {}
            warn_counts = {}
            if sched and sm.get("mold_code"):
                c2 = conn.cursor()
                mold_expr = f"UPPER(TRIM(TO_CHAR({sm['mold_code']})))"
                cyc = sm.get("cycle")
                cum = sm.get("cumulative")
                warn_pct = int(self.cfg.get("warning_pct") or 90)

                if cyc and cum:
                    c2.execute(
                        f"SELECT {mold_expr}, COUNT(*), "
                        f"SUM(CASE WHEN NVL({cyc},0)>0 AND NVL({cum},0)>=NVL({cyc},0) THEN 1 ELSE 0 END), "
                        f"SUM(CASE WHEN NVL({cyc},0)>0 "
                        f"          AND NVL({cum},0)<NVL({cyc},0) "
                        f"          AND NVL({cum},0)>=NVL({cyc},0)*:wp/100 THEN 1 ELSE 0 END) "
                        f"FROM {sched} GROUP BY {mold_expr}",
                        wp=warn_pct
                    )
                    for k, cnt, due, warn in c2.fetchall():
                        kk = str(k or "").strip().upper()
                        rule_counts[kk] = int(cnt or 0)
                        due_counts[kk] = int(due or 0)
                        warn_counts[kk] = int(warn or 0)
                else:
                    c2.execute(
                        f"SELECT {mold_expr}, COUNT(*) FROM {sched} GROUP BY {mold_expr}"
                    )
                    for k, cnt in c2.fetchall():
                        rule_counts[str(k or "").strip().upper()] = int(cnt or 0)

            rows = []
            for rr in cur.fetchall():
                d = {}
                for i, key in enumerate(aliases):
                    v = rr[i]
                    d[key] = self.core.show(v) if isinstance(v, (dt.date, dt.datetime)) else v
                code_s = self.core.show(d.get("mold_code")).strip()
                cnt = rule_counts.get(code_s.upper(), 0)
                use = use_map.get(code_s.upper()) or {}
                d.update({
                    "rule_count": cnt,
                    "due_count": due_counts.get(code_s.upper(), 0),
                    "warn_count": warn_counts.get(code_s.upper(), 0),
                    "in_use": bool(use.get("in_use")),
                    "current_machine": use.get("machine") or "",
                    "current_work_order": use.get("work_order_no") or "",
                    "current_item_code": use.get("item_code") or "",
                    "current_start_date": use.get("start_date") or "",
                    "current_use_source": use.get("source") or "",
                })
                rows.append(d)

            # 실제 DB 컬럼명이 무엇으로 잡혔는지 화면에서 참고 가능
            labels = {}
            default_labels = {
                "mold_status":"금형상태","mold_code":"금형코드","mold_group":"금형그룹",
                "drawing_no":"도면번호","prod_seq":"생산제품","mold_name":"품명(금형)",
                "mold_spec":"금형규격",
                "item_code":"품번(금형)","barcode":"바코드","mold_type":"금형유형",
                "life_limit":"한계수명","shot":"SHOT","supplier":"공급상",
                "purchase_type":"금형구입유형","country_code":"국가코드",
                "description":"설명","cavity":"캐비티","tt":"T/T","location":"금형위치",
                "version":"금형버전","serial":"금형시리얼"
            }
            for key, col in picks.items():
                if col:
                    labels[key] = display.get(col) or comments.get(col) or default_labels.get(key) or col
            labels.update({
                "rule_count":"점검항목수","due_count":"점검도래","warn_count":"점검예정",
                "current_machine":"현재사용호기",
                "current_work_order":"작업지시번호"
            })

            return {
                "configured": self.is_configured(),
                "rows": rows,
                "total_count": len(rows),
                "labels": labels,
                "available_fields": [k for k,v in picks.items() if v]
            }
        return self.app.run_db(work)

    def mold_detail(self, body):
        """선택 금형의 전체 금형마스터 행을 표시이름과 함께 반환."""
        mold = str((body or {}).get("mold_code") or "").strip()
        if not mold:
            raise self.UserError("금형코드를 선택하세요.")

        def work(conn):
            table, code_col, name_col, _cols = self._mold_master_info(conn)
            comments = self._mold_col_comments(conn, table)
            display = self._mold_display_map()
            cur = conn.cursor()
            cur.execute(
                f"SELECT M.* FROM {table} M "
                f"WHERE UPPER(TRIM(TO_CHAR(M.{code_col})))=UPPER(TRIM(TO_CHAR(:m)))",
                m=mold
            )
            row = cur.fetchone()
            if row is None:
                raise self.UserError("금형마스터에서 금형을 찾지 못했습니다.")
            names = [d[0] for d in cur.description]
            items = []
            for c, v in zip(names, row):
                label = display.get(c) or comments.get(c) or c
                vv = self.core.show(v) if isinstance(v, (dt.date, dt.datetime)) else v
                items.append({"col":c, "label":label, "value":vv})
            return {"mold_code": mold, "items": items}
        return self.app.run_db(work)


    def rules_for_mold(self, body):
        self._need_config()
        mold = str((body or {}).get("mold_code") or "").strip()
        if not mold:
            raise self.UserError("금형코드를 선택하세요.")
        sm = self.cfg["schedule_cols"]
        table = self._table(self.cfg["schedule_table"])
        fields, sqls = self._select_parts(sm)
        with self.lock:
            assignments = self._load_assignments()

        def work(conn):
            use_map = self._current_mold_use(conn)
            cur = conn.cursor()
            sql = (
                f"SELECT ROWIDTOCHAR(T.ROWID), {', '.join(sqls)} "
                f"FROM {table} T "
                f"WHERE UPPER(TRIM(TO_CHAR(T.{sm['mold_code']})))="
                f"      UPPER(TRIM(TO_CHAR(:m))) "
                f"ORDER BY T.{sm['check_type']}"
            )
            cur.execute(sql, m=mold)
            rows = []
            warn = int(self.cfg.get("warning_pct") or 90)
            for r in cur.fetchall():
                d = {"rid": r[0]}
                for i, k in enumerate(fields, 1):
                    v = r[i]
                    d[k] = self.core.show(v) if isinstance(v, (dt.date, dt.datetime)) else v
                cyc = self._num(d.get("cycle"))
                cum = self._num(d.get("cumulative"))
                pct = (cum / cyc * 100.0) if cyc > 0 else 0
                d["remaining"] = cyc - cum if cyc > 0 else 0
                d["progress"] = round(pct, 1)
                d["status"] = "due" if cyc > 0 and cum >= cyc else ("warn" if cyc > 0 and pct >= warn else "ok")
                code = str(d.get("check_type") or "").strip().upper()
                d["check_type_label"] = CHECK_TYPE_LABELS.get(code, code)
                a = assignments.get(self._assignment_key(d.get("mold_code") or mold, code, cyc)) or {}
                d["assignee"] = a.get("assignee") or ""
                d["assigned_at"] = a.get("assigned_at") or ""
                use = use_map.get(str(d.get("mold_code") or mold).strip().upper()) or {}
                d["in_use"] = bool(use.get("in_use"))
                d["current_machine"] = use.get("machine") or ""
                d["current_work_order"] = use.get("work_order_no") or ""
                d["current_item_code"] = use.get("item_code") or ""
                d["current_start_date"] = use.get("start_date") or ""
                rows.append(d)
            return {"configured": True, "mold_code": mold, "rows": rows,
                    "check_type_labels": dict(CHECK_TYPE_LABELS)}
        return self.app.run_db(work)

    def _mold_master_row(self, conn, mold_code):
        table, code_col, name_col, _cols = self._mold_master_info(conn)
        cur = conn.cursor()
        cur.execute(
            f"SELECT M.* FROM {table} M "
            f"WHERE UPPER(TRIM(TO_CHAR(M.{code_col})))=UPPER(TRIM(TO_CHAR(:m)))",
            m=mold_code
        )
        row = cur.fetchone()
        if row is None:
            raise self.UserError(f"금형마스터에 없는 금형코드입니다: {mold_code}")
        names = [d[0] for d in cur.description]
        data = dict(zip(names, row))
        return {
            "table": table,
            "code_col": code_col,
            "name_col": name_col,
            "row": data,
            "mold_code_value": data.get(code_col),
            "mold_name_value": data.get(name_col) if name_col else None,
        }

    def _current_mold_use(self, conn):
        """
        현재 사용중 금형 판정.
        - 작업지시 START/END
        - 작업지시 상태
        - 최근 작업의 계획수량/실적수량
        - 금형마스터 위치/상태 컬럼의 '생산중'
        을 함께 사용합니다.
        """
        out = {}
        recent = {}

        try:
            wo = self.mes.qualify(self.cfg_main.get("wo_table") or "IPLN_WORK_ORDER_MASTER")
            owner, tname = wo.split(".") if "." in wo else (self._owner(), wo)

            c2 = conn.cursor()
            c2.execute("""
                SELECT COLUMN_NAME
                  FROM ALL_TAB_COLUMNS
                 WHERE OWNER=:o AND TABLE_NAME=:t
            """, o=owner.upper(), t=tname.upper())
            cols = {r[0] for r in c2.fetchall()}

            if "MOLD_CODE" in cols and "MACHINE_CODE" in cols:
                def sel(c):
                    return f"T.{c}" if c in cols else "NULL"

                date_cond = ""
                if "WORK_ORDER_DATE" in cols:
                    date_cond = "AND T.WORK_ORDER_DATE >= TRUNC(SYSDATE) - 60"

                order_parts = []
                if "START_DATE" in cols:
                    order_parts.append("T.START_DATE DESC NULLS LAST")
                if "WORK_ORDER_DATE" in cols:
                    order_parts.append("T.WORK_ORDER_DATE DESC NULLS LAST")
                if "WORK_ORDER_NO" in cols:
                    order_parts.append("T.WORK_ORDER_NO DESC")
                order_sql = ", ".join(order_parts) or "T.ROWID DESC"

                sql = f"""
                    SELECT MOLD_CODE, MACHINE_CODE, MACHINE_NAME, WORK_ORDER_NO,
                           ITEM_CODE, ITEM_NAME, WORK_ORDER_DATE,
                           START_DATE, END_DATE,
                           WORK_ORDER_STATUS, PLAN_STATUS,
                           PLAN_QTY, ACTUAL_QTY
                      FROM (
                            SELECT T.MOLD_CODE,
                                   T.MACHINE_CODE,
                                   {sel("MACHINE_NAME")} AS MACHINE_NAME,
                                   {sel("WORK_ORDER_NO")} AS WORK_ORDER_NO,
                                   {sel("ITEM_CODE")} AS ITEM_CODE,
                                   {sel("ITEM_NAME")} AS ITEM_NAME,
                                   {sel("WORK_ORDER_DATE")} AS WORK_ORDER_DATE,
                                   {sel("START_DATE")} AS START_DATE,
                                   {sel("END_DATE")} AS END_DATE,
                                   {sel("WORK_ORDER_STATUS")} AS WORK_ORDER_STATUS,
                                   {sel("PLAN_STATUS")} AS PLAN_STATUS,
                                   {sel("PLAN_QTY")} AS PLAN_QTY,
                                   {sel("ACTUAL_QTY")} AS ACTUAL_QTY,
                                   ROW_NUMBER() OVER (
                                       PARTITION BY UPPER(TRIM(TO_CHAR(T.MOLD_CODE)))
                                       ORDER BY {order_sql}
                                   ) RN
                              FROM {wo} T
                             WHERE T.MOLD_CODE IS NOT NULL
                               AND NVL(TRIM(TO_CHAR(T.MOLD_CODE)), '*') <> '*'
                               AND T.MACHINE_CODE IS NOT NULL
                               {date_cond}
                           )
                     WHERE RN <= 8
                """

                cur = conn.cursor()
                cur.execute(sql)

                done_words = ("DONE", "END", "FINISH", "CLOSE", "COMPLETE", "CANCEL",
                              "완료", "종료", "마감", "취소")
                active_words = ("RUN", "START", "WORK", "PROD", "PROCESS", "ING",
                                "진행", "작업", "생산", "시작")
                now = dt.datetime.now()

                for (mold, mc, mn, wono, item, itemname, wodate, st, ed,
                     wstatus, pstatus, plan_qty, actual_qty) in cur.fetchall():

                    key = self.core.show(mold).strip().upper()
                    if not key:
                        continue

                    mc_s = self.core.show(mc).strip()
                    mn_s = self.core.show(mn).strip()
                    machine = (
                        f"{mn_s} ({mc_s})"
                        if mn_s and mc_s and mn_s.upper() != mc_s.upper()
                        else (mn_s or mc_s)
                    )

                    info = {
                        "in_use": False,
                        "machine_code": mc_s,
                        "machine_name": mn_s,
                        "machine": machine,
                        "work_order_no": self.core.show(wono).strip(),
                        "item_code": self.core.show(item).strip(),
                        "item_name": self.core.show(itemname).strip(),
                        "start_date": self.core.show(st or wodate),
                        "source": "",
                    }

                    if key not in recent:
                        recent[key] = dict(info)

                    explicit = (st is not None and ed is None)

                    status_text = (
                        self.core.show(wstatus) + " " + self.core.show(pstatus)
                    ).upper().replace(" ", "")
                    has_done = any(w.replace(" ", "") in status_text for w in done_words)
                    has_active = any(w.replace(" ", "") in status_text for w in active_words)
                    status_active = bool(status_text and has_active and not has_done)

                    qty_active = False
                    try:
                        pq = float(plan_qty or 0)
                        aq = float(actual_qty or 0)
                        if pq > 0 and aq < pq:
                            d = wodate or st
                            if isinstance(d, dt.datetime):
                                qty_active = (now - d).days <= 2
                            elif isinstance(d, dt.date):
                                qty_active = (now.date() - d).days <= 2
                    except Exception:
                        qty_active = False

                    if explicit or status_active or qty_active:
                        info["in_use"] = True
                        info["source"] = (
                            "작업지시 시작/종료" if explicit else
                            "작업지시 상태" if status_active else
                            "최근 작업지시 수량"
                        )
                        if key not in out:
                            out[key] = info

            # 금형마스터의 '생산중' 값을 보완 기준으로 사용
            try:
                mt, code_col, _name_col, mcols = self._mold_master_info(conn)
                comments = self._mold_col_comments(conn, mt)
                display = self._mold_display_map()

                owner_m, tname_m = mt.split(".") if "." in mt else (self._owner(), mt)
                cm = conn.cursor()
                cm.execute("""
                    SELECT COLUMN_NAME, DATA_TYPE
                      FROM ALL_TAB_COLUMNS
                     WHERE OWNER=:o AND TABLE_NAME=:t
                     ORDER BY COLUMN_ID
                """, o=owner_m.upper(), t=tname_m.upper())

                text_cols = [
                    c for c, typ in cm.fetchall()
                    if typ in ("CHAR", "VARCHAR2", "NVARCHAR2", "NCHAR")
                ]

                state_cols = []
                for c in text_cols:
                    label = " ".join([
                        c, display.get(c, ""), comments.get(c, "")
                    ]).upper().replace(" ", "")
                    if any(k in label for k in (
                        "위치", "상태", "업체", "LOCATION", "STATUS", "STATE", "POSITION"
                    )):
                        state_cols.append(c)

                if not state_cols:
                    for c in ("MOLD_LOCATION", "LOCATION", "LOC_CODE", "MOLD_STATUS", "STATUS"):
                        if c in mcols:
                            state_cols.append(c)

                if state_cols:
                    prod_conds = [
                        f"INSTR(REPLACE(UPPER(NVL(TO_CHAR(M.{c}),'')),' ',''),'생산중') > 0"
                        for c in state_cols
                    ]
                    cm.execute(
                        f"SELECT M.{code_col} FROM {mt} M WHERE "
                        + " OR ".join(prod_conds)
                    )
                    for (mold,) in cm.fetchall():
                        key = self.core.show(mold).strip().upper()
                        if not key or key in out:
                            continue
                        info = dict(recent.get(key) or {})
                        info.update({"in_use": True, "source": "금형마스터 생산중"})
                        if not info.get("machine"):
                            info.update({
                                "machine_code": "",
                                "machine_name": "",
                                "machine": "호기 미확인",
                                "work_order_no": "",
                                "item_code": "",
                                "item_name": "",
                                "start_date": "",
                            })
                        out[key] = info
            except Exception:
                pass

        except Exception:
            return {}

        return out

    def list_rules(self, body=None, due_only=False):
        if not self.is_configured():
            return {"configured": False, "rows": [], "warning_pct": int(self.cfg.get("warning_pct") or 90)}
        body = body or {}
        q = str(body.get("q") or "").strip()
        due_only = due_only or bool(body.get("due_only"))
        sm = self.cfg["schedule_cols"]
        fields, sqls = self._select_parts(sm)
        table = self._table(self.cfg["schedule_table"])
        with self.lock:
            assignments = self._load_assignments()

        def work(conn):
            use_map = self._current_mold_use(conn)
            conds, binds = [], {}
            if q:
                likes = []
                for k in ("mold_code", "mold_name", "check_type", "description"):
                    c = sm.get(k)
                    if c:
                        likes.append(f"UPPER(TO_CHAR(T.{c})) LIKE :q")
                # 한글 점검유형(세척/연마/수리/부품교체/정기보전)으로도 검색
                q_codes = [code for code, label in CHECK_TYPE_LABELS.items()
                           if q.upper() in code.upper() or q in label]
                if q_codes and sm.get("check_type"):
                    ph = []
                    for n, code in enumerate(q_codes):
                        key = f"qt{n}"
                        ph.append(f":{key}")
                        binds[key] = code
                    likes.append(f"UPPER(TO_CHAR(T.{sm['check_type']})) IN ({', '.join(ph)})")
                if likes:
                    conds.append("(" + " OR ".join(likes) + ")")
                    binds["q"] = "%" + q.upper() + "%"
            cyc, cum = sm.get("cycle"), sm.get("cumulative")
            if due_only:
                conds.append(f"NVL(T.{cyc},0) > 0")
                conds.append(f"NVL(T.{cum},0) >= NVL(T.{cyc},0)")
            sql = f"SELECT ROWIDTOCHAR(T.ROWID), {', '.join(sqls)} FROM {table} T"
            if conds:
                sql += " WHERE " + " AND ".join(conds)
            order = [sm.get("mold_code"), sm.get("check_type")]
            order = [x for x in order if x]
            if order:
                sql += " ORDER BY " + ", ".join("T." + x for x in order)
            lim = 200 if due_only else 5000
            sql = f"SELECT * FROM ({sql}) WHERE ROWNUM <= {lim}"
            cur = conn.cursor()
            cur.execute(sql, binds)
            rows = []
            warn = int(self.cfg.get("warning_pct") or 90)
            for r in cur.fetchall():
                d = {"rid": r[0]}
                for i, k in enumerate(fields, 1):
                    d[k] = self.core.show(r[i]) if isinstance(r[i], (dt.date, dt.datetime)) else r[i]
                cycle = self._num(d.get("cycle"))
                cumu = self._num(d.get("cumulative"))
                rem = cycle - cumu if cycle > 0 else 0
                pct = (cumu / cycle * 100.0) if cycle > 0 else 0
                d["remaining"] = rem
                d["progress"] = round(pct, 1)
                d["status"] = "due" if cycle > 0 and cumu >= cycle else ("warn" if cycle > 0 and pct >= warn else "ok")
                code = str(d.get("check_type") or "").strip().upper()
                d["check_type_label"] = CHECK_TYPE_LABELS.get(code, code)
                a = assignments.get(self._assignment_key(d.get("mold_code"), code, cycle)) or {}
                d["assignee"] = a.get("assignee") or ""
                d["assigned_at"] = a.get("assigned_at") or ""

                # 현재 사용중 설비/호기
                mold_key = str(d.get("mold_code") or "").strip().upper()
                use = use_map.get(mold_key) or {}
                d["in_use"] = bool(use.get("in_use"))
                d["machine_code"] = use.get("machine_code") or ""
                d["machine_name"] = use.get("machine_name") or ""
                d["current_machine"] = use.get("machine") or ""
                d["current_work_order"] = use.get("work_order_no") or ""
                d["current_item_code"] = use.get("item_code") or ""
                d["current_item_name"] = use.get("item_name") or ""
                d["current_start_date"] = use.get("start_date") or ""
                rows.append(d)
            return {"configured": True, "rows": rows, "warning_pct": warn,
                    "check_type_labels": dict(CHECK_TYPE_LABELS),
                    "popup_enabled": self.cfg.get("popup_enabled", True) is not False,
                    "poll_seconds": int(self.cfg.get("poll_seconds") or 60),
                    "refresh_seconds": int(self.cfg.get("refresh_seconds") or 300)}
        return self.app.run_db(work)

    def due(self, body=None):
        return self.list_rules(body or {}, due_only=True)

    def update_rule(self, body, user):
        self._need_config()
        rid = self._rid(body.get("rid"))
        sm = self.cfg["schedule_cols"]
        sets, binds = [], {"rid": rid}
        editable = {
            "check_type": body.get("check_type"),
            "cycle": body.get("cycle"),
            "description": body.get("description"),
            "approval": body.get("approval"),
        }
        if sm.get("check_type"):
            v = str(editable["check_type"] or "").strip()
            if not v:
                raise self.UserError("점검유형은 비울 수 없습니다.")
            sets.append(f"{sm['check_type']}=:check_type")
            binds["check_type"] = v
        if sm.get("cycle"):
            try:
                v = float(str(editable["cycle"]).replace(",", ""))
            except Exception:
                raise self.UserError("점검주기는 숫자로 입력하세요.")
            if v <= 0:
                raise self.UserError("점검주기는 0보다 커야 합니다.")
            sets.append(f"{sm['cycle']}=:cycle")
            binds["cycle"] = v
        if sm.get("description"):
            sets.append(f"{sm['description']}=:description")
            binds["description"] = str(editable["description"] or "").strip() or None
        if sm.get("approval"):
            sets.append(f"{sm['approval']}=:approval")
            binds["approval"] = str(editable["approval"] or "").strip() or None
        uname = str(user or "").split("(실행", 1)[0].strip()[:50] or "WEB"
        if sm.get("updated_at"):
            sets.append(f"{sm['updated_at']}=SYSDATE")
        if sm.get("updated_by"):
            sets.append(f"{sm['updated_by']}=:upd_user")
            binds["upd_user"] = uname

        def work(conn):
            table = self._table(self.cfg['schedule_table'])
            cur = conn.cursor()
            keys = [k for k in ("mold_code","mold_name","check_type","cycle","cumulative","description","approval") if sm.get(k)]
            cur.execute(
                f"SELECT {', '.join('T.'+sm[k] for k in keys)} FROM {table} T "
                "WHERE ROWID=CHARTOROWID(:rid) FOR UPDATE", rid=rid
            )
            row = cur.fetchone()
            if row is None:
                raise self.UserError("수정할 점검항목을 찾지 못했습니다. 다시 조회하세요.")
            old = dict(zip(keys, row))
            cur.execute(f"UPDATE {table} SET {', '.join(sets)} WHERE ROWID=CHARTOROWID(:rid)", binds)
            if cur.rowcount != 1:
                conn.rollback()
                raise self.UserError("수정할 점검항목을 찾지 못했습니다. 다시 조회하세요.")
            conn.commit()
            new = dict(old)
            if sm.get("check_type"): new["check_type"] = binds.get("check_type")
            if sm.get("cycle"): new["cycle"] = binds.get("cycle")
            if sm.get("description"): new["description"] = binds.get("description")
            if sm.get("approval"): new["approval"] = binds.get("approval")
            return {"ok": True, "old": old, "new": new}
        out = self.app.run_db(work)
        old, new = out.get("old") or {}, out.get("new") or {}
        before = f"유형={self.core.show(old.get('check_type'))}, 주기={self.core.show(old.get('cycle'))}, 승인={self.core.show(old.get('approval'))}, 설명={self.core.show(old.get('description'))}"
        after = f"유형={self.core.show(new.get('check_type'))}, 주기={self.core.show(new.get('cycle'))}, 승인={self.core.show(new.get('approval'))}, 설명={self.core.show(new.get('description'))}"
        cyc = self._num(new.get("cycle")); cum = self._num(new.get("cumulative")); pct = (cum/cyc*100.0) if cyc>0 else 0
        self._append_audit(actor=uname, process_type="항목수정", mold_code=new.get("mold_code"), mold_name=new.get("mold_name"),
                           check_type=new.get("check_type"), cycle=new.get("cycle"), cumulative=new.get("cumulative"), progress=round(pct,1),
                           before=before, after=after, description="예방점검 항목 수정")
        return {"ok": True}


    def _constraint_columns(self, conn, table):
        """PK/UNIQUE 제약조건 컬럼 집합. 새 행 복제 시 별도 ID 중복을 피하기 위해 사용."""
        owner = self._owner()
        tname = self._table_name_only(table)
        cur = conn.cursor()
        cur.execute("""
            SELECT AC.CONSTRAINT_TYPE, ACC.CONSTRAINT_NAME, ACC.COLUMN_NAME, ACC.POSITION
              FROM ALL_CONSTRAINTS AC
              JOIN ALL_CONS_COLUMNS ACC
                ON ACC.OWNER=AC.OWNER AND ACC.CONSTRAINT_NAME=AC.CONSTRAINT_NAME
             WHERE AC.OWNER=:o AND AC.TABLE_NAME=:t
               AND AC.CONSTRAINT_TYPE IN ('P','U')
             ORDER BY ACC.CONSTRAINT_NAME, ACC.POSITION
        """, o=owner, t=tname)
        out = {}
        for typ, name, col, pos in cur.fetchall():
            out.setdefault(name, {"type": typ, "cols": []})["cols"].append(col)
        return list(out.values())

    def _insertable_columns(self, conn, table):
        owner = self._owner()
        tname = self._table_name_only(table)
        cur = conn.cursor()
        # Oracle 11g 이상에서 VIRTUAL_COLUMN 사용 가능
        try:
            cur.execute("""
                SELECT COLUMN_NAME, DATA_TYPE, NULLABLE, DATA_DEFAULT, COLUMN_ID, VIRTUAL_COLUMN
                  FROM ALL_TAB_COLUMNS
                 WHERE OWNER=:o AND TABLE_NAME=:t
                 ORDER BY COLUMN_ID
            """, o=owner, t=tname)
            return [
                {"name": r[0], "type": r[1], "nullable": r[2], "default": r[3],
                 "position": r[4], "virtual": r[5]}
                for r in cur.fetchall()
            ]
        except Exception:
            cur.execute("""
                SELECT COLUMN_NAME, DATA_TYPE, NULLABLE, DATA_DEFAULT, COLUMN_ID
                  FROM ALL_TAB_COLUMNS
                 WHERE OWNER=:o AND TABLE_NAME=:t
                 ORDER BY COLUMN_ID
            """, o=owner, t=tname)
            return [
                {"name": r[0], "type": r[1], "nullable": r[2], "default": r[3],
                 "position": r[4], "virtual": "NO"}
                for r in cur.fetchall()
            ]

    def add_rule(self, body, user):
        """
        점검항목 추가.

        두 가지 경우를 모두 지원:
        1) 기존 점검항목이 있는 금형:
           그 금형의 기존 행을 템플릿으로 복제.
        2) 신규 금형처럼 점검항목이 0건인 금형:
           금형마스터에서 금형 존재를 확인한 뒤, 예방점검 테이블의 기존 행을
           '구조 템플릿'으로 사용하고 금형코드/금형명/점검유형/주기 등을 새 값으로 덮어씀.

        따라서 자주보전 항목이 아직 하나도 없는 신규 금형도 등록할 수 있습니다.
        """
        self._need_config()
        sm = self.cfg["schedule_cols"]

        template_rid = str(body.get("template_rid") or "").strip()
        mold_code_text = str(body.get("mold_code") or "").strip()
        check_type = str(body.get("check_type") or "").strip().upper()

        if not check_type:
            raise self.UserError("점검유형을 선택하세요.")
        try:
            cycle = float(str(body.get("cycle") or "").replace(",", ""))
        except Exception:
            raise self.UserError("점검주기는 숫자로 입력하세요.")
        if cycle <= 0:
            raise self.UserError("점검주기는 0보다 커야 합니다.")
        try:
            initial = float(str(body.get("cumulative") or "0").replace(",", ""))
        except Exception:
            raise self.UserError("초기 누적타발수는 숫자로 입력하세요.")
        if initial < 0:
            raise self.UserError("초기 누적타발수는 음수가 될 수 없습니다.")

        description = str(body.get("description") or "").strip() or None
        approval = str(body.get("approval") or "").strip() or None
        uname = str(user or "").split("(실행", 1)[0].strip()[:50] or "WEB"
        date_text = str(body.get("check_date") or "").strip()
        try:
            check_dt = dt.datetime.strptime(date_text[:16], "%Y-%m-%d %H:%M") if len(date_text) >= 16 \
                else dt.datetime.strptime(date_text[:10], "%Y-%m-%d")
        except Exception:
            check_dt = dt.datetime.now()

        def work(conn):
            table = self._table(self.cfg["schedule_table"])
            cur = conn.cursor()

            # 대상 금형 확정.
            if template_rid:
                rid = self._rid(template_rid)
                cur.execute(f"SELECT T.* FROM {table} T WHERE ROWID=CHARTOROWID(:rid) FOR UPDATE",
                            rid=rid)
                row = cur.fetchone()
                if row is None:
                    raise self.UserError("추가 기준이 될 점검항목을 찾지 못했습니다.")
                names = [d[0] for d in cur.description]
                template = dict(zip(names, row))
                target_mold = template.get(sm["mold_code"])
                master = self._mold_master_row(conn, self.core.show(target_mold))
            else:
                if not mold_code_text:
                    raise self.UserError("추가할 금형을 선택하세요.")
                master = self._mold_master_row(conn, mold_code_text)
                target_mold = master["mold_code_value"]

                # 해당 금형에 기존 점검항목이 있으면 그 첫 행을 템플릿으로 사용.
                cur.execute(
                    f"SELECT T.* FROM {table} T "
                    f"WHERE UPPER(TRIM(TO_CHAR(T.{sm['mold_code']})))="
                    f"      UPPER(TRIM(TO_CHAR(:m))) AND ROWNUM=1",
                    m=target_mold
                )
                row = cur.fetchone()
                if row is not None:
                    names = [d[0] for d in cur.description]
                    template = dict(zip(names, row))
                else:
                    # 신규 금형: 같은 점검유형 템플릿 우선, 없으면 아무 기존행.
                    cur.execute(
                        f"SELECT T.* FROM {table} T "
                        f"WHERE UPPER(TRIM(TO_CHAR(T.{sm['check_type']})))=:ct AND ROWNUM=1",
                        ct=check_type
                    )
                    row = cur.fetchone()
                    if row is None:
                        cur.execute(f"SELECT T.* FROM {table} T WHERE ROWNUM=1")
                        row = cur.fetchone()
                    if row is None:
                        raise self.UserError(
                            "예방점검 테이블에 기준으로 복사할 기존 행이 한 건도 없습니다. "
                            "DB 기본값 확인이 필요합니다."
                        )
                    names = [d[0] for d in cur.description]
                    template = dict(zip(names, row))

            # 같은 금형 + 같은 점검유형 중복 방지
            cur.execute(
                f"SELECT COUNT(*) FROM {table} "
                f"WHERE UPPER(TRIM(TO_CHAR({sm['mold_code']})))="
                f"      UPPER(TRIM(TO_CHAR(:m))) "
                f"AND UPPER(TRIM(TO_CHAR({sm['check_type']})))=:ctype",
                m=target_mold, ctype=check_type
            )
            if cur.fetchone()[0]:
                raise self.UserError(
                    f"이 금형에는 이미 같은 점검유형({CHECK_TYPE_LABELS.get(check_type, check_type)})이 있습니다."
                )

            meta = self._insertable_columns(conn, self.cfg["schedule_table"])
            constraints = self._constraint_columns(conn, self.cfg["schedule_table"])
            mapped_cols = {c for c in sm.values() if c}

            # 단일 PK/UNIQUE 식별자 컬럼은 복제하지 않고 DB default/trigger에 맡김.
            omit_unique = set()
            for con in constraints:
                cols = con["cols"]
                if len(cols) == 1 and cols[0] not in mapped_cols:
                    omit_unique.add(cols[0])

            # 템플릿 값을 기반으로 INSERT VALUES 구성
            vals = dict(template)
            vals[sm["mold_code"]] = target_mold
            if sm.get("mold_name"):
                vals[sm["mold_name"]] = master.get("mold_name_value")
            vals[sm["check_type"]] = check_type
            vals[sm["cycle"]] = cycle
            vals[sm["cumulative"]] = initial
            if sm.get("description"): vals[sm["description"]] = description
            if sm.get("approval"): vals[sm["approval"]] = approval
            if sm.get("check_date"): vals[sm["check_date"]] = check_dt
            if sm.get("created_at"): vals[sm["created_at"]] = dt.datetime.now()
            if sm.get("created_by"): vals[sm["created_by"]] = uname
            if sm.get("updated_at"): vals[sm["updated_at"]] = dt.datetime.now()
            if sm.get("updated_by"): vals[sm["updated_by"]] = uname

            # 금형마스터와 같은 이름의 조직/회사/공장 관련 컬럼이면 신규 금형 값을 우선 복사.
            master_row = master.get("row") or {}
            for c in list(vals):
                if c in master_row and c not in (
                    sm.get("check_type"), sm.get("cycle"), sm.get("cumulative"),
                    sm.get("description"), sm.get("approval"), sm.get("check_date"),
                    sm.get("created_at"), sm.get("created_by"),
                    sm.get("updated_at"), sm.get("updated_by")
                ):
                    if c == sm.get("mold_code") or c == sm.get("mold_name") or \
                       any(w in c for w in ("ORG", "COMPANY", "CORP", "PLANT", "SITE", "FACTORY", "BIZ")):
                        vals[c] = master_row.get(c)

            cols, binds = [], {}
            for m in meta:
                c = m["name"]
                if str(m.get("virtual") or "").upper() == "YES":
                    continue
                if c in omit_unique:
                    continue

                v = vals.get(c)
                # 컬럼에 DB default가 있고 템플릿 값도 비어 있으면 INSERT 대상에서 제외.
                if v is None and m.get("default") is not None and c not in mapped_cols:
                    continue

                cols.append(c)
                binds[f"b{len(cols)-1}"] = v

            sql = (
                f"INSERT INTO {table} ({', '.join(cols)}) VALUES ("
                + ", ".join(f":b{i}" for i in range(len(cols))) + ")"
            )
            cur.execute(sql, binds)
            if cur.rowcount != 1:
                raise self.UserError("점검항목을 추가하지 못했습니다.")
            conn.commit()

            return {
                "ok": True,
                "mold_code": self.core.show(target_mold),
                "mold_name": self.core.show(master.get("mold_name_value")),
                "check_type": check_type,
                "check_type_label": CHECK_TYPE_LABELS.get(check_type, check_type),
                "cycle": cycle,
                "cumulative": initial,
            }

        out = self.app.run_db(work)
        cyc = self._num(out.get("cycle")); cum = self._num(out.get("cumulative")); pct = (cum/cyc*100.0) if cyc>0 else 0
        self._append_audit(actor=uname, process_type="항목추가", mold_code=out.get("mold_code"), mold_name=out.get("mold_name"),
                           check_type=out.get("check_type"), cycle=out.get("cycle"), cumulative=out.get("cumulative"), progress=round(pct,1),
                           after=f"주기={self.core.show(out.get('cycle'))}, 초기누적={self.core.show(out.get('cumulative'))}",
                           description="예방점검 항목 추가")
        return out


    def delete_rule(self, body, user):
        self._need_config()
        rid = self._rid(body.get("rid"))
        sm = self.cfg["schedule_cols"]
        uname = str(user or "").split("(실행", 1)[0].strip()[:50] or "WEB"

        def work(conn):
            table = self._table(self.cfg["schedule_table"])
            cur = conn.cursor()

            sels = []
            keys = []
            for key in ("mold_code", "mold_name", "check_type", "cycle", "cumulative"):
                c = sm.get(key)
                if c:
                    sels.append(f"T.{c}")
                    keys.append(key)
            cur.execute(
                f"SELECT {', '.join(sels)} FROM {table} T "
                "WHERE ROWID=CHARTOROWID(:rid) FOR UPDATE",
                rid=rid
            )
            row = cur.fetchone()
            if row is None:
                raise self.UserError("삭제할 점검항목을 찾지 못했습니다. 다시 조회하세요.")
            old = dict(zip(keys, row))

            cur.execute(f"DELETE FROM {table} WHERE ROWID=CHARTOROWID(:rid)", rid=rid)
            if cur.rowcount != 1:
                raise self.UserError("점검항목을 삭제하지 못했습니다.")
            conn.commit()

            code = str(old.get("check_type") or "").strip().upper()
            return {
                "ok": True,
                "mold_code": self.core.show(old.get("mold_code")),
                "mold_name": self.core.show(old.get("mold_name")),
                "check_type": code,
                "check_type_label": CHECK_TYPE_LABELS.get(code, code),
                "cycle": self._num(old.get("cycle")),
                "cumulative": self._num(old.get("cumulative")),
            }

        out = self.app.run_db(work)
        cyc = self._num(out.get("cycle")); cum = self._num(out.get("cumulative")); pct = (cum/cyc*100.0) if cyc>0 else 0
        self._append_audit(actor=uname, process_type="항목삭제", mold_code=out.get("mold_code"), mold_name=out.get("mold_name"),
                           check_type=out.get("check_type"), cycle=out.get("cycle"), cumulative=out.get("cumulative"), progress=round(pct,1),
                           before=f"주기={self.core.show(out.get('cycle'))}, 누적={self.core.show(out.get('cumulative'))}",
                           description="예방점검 항목 삭제")
        return out


    # ---------------------------------------------------------------
    # history
    # ---------------------------------------------------------------
    def history(self, body=None):
        if not self.is_configured():
            return {"configured": False, "rows": []}
        body = body or {}
        hm = self.cfg["history_cols"]
        fields = [k for k, _l, _r in HISTORY_FIELDS if hm.get(k)]
        sels = [f"T.{hm[k]}" for k in fields]
        table = self._table(self.cfg["history_table"])
        mold = str(body.get("mold_code") or "").strip()
        q = str(body.get("q") or "").strip()
        limit = max(1, min(3000, int(body.get("limit") or 1000)))
        process_map = self._audit_process_map()

        def work(conn):
            conds, binds = [], {}
            if mold and hm.get("mold_code"):
                conds.append(
                    f"UPPER(TRIM(TO_CHAR(T.{hm['mold_code']})))="
                    f"UPPER(TRIM(TO_CHAR(:mold)))"
                )
                binds["mold"] = mold
            if q:
                likes = []
                for k in ("mold_code", "mold_name", "check_type", "description", "created_by"):
                    c = hm.get(k)
                    if c:
                        likes.append(f"UPPER(TO_CHAR(T.{c})) LIKE :q")
                if likes:
                    conds.append("(" + " OR ".join(likes) + ")")
                    binds["q"] = "%" + q.upper() + "%"
            sql0 = f"SELECT ROWIDTOCHAR(T.ROWID), {', '.join(sels)} FROM {table} T"
            if conds:
                sql0 += " WHERE " + " AND ".join(conds)
            order_col = hm.get("check_date") or hm.get("created_at")
            if order_col:
                sql0 += f" ORDER BY T.{order_col} DESC"
            sql = f"SELECT * FROM ({sql0}) WHERE ROWNUM <= {limit}"
            cur = conn.cursor()
            cur.execute(sql, binds)
            rows = []
            for r in cur.fetchall():
                d = {"rid": r[0]}
                for i, k in enumerate(fields, 1):
                    v = r[i]
                    d[k] = self.core.show(v) if isinstance(v, (dt.date, dt.datetime)) else v
                code = str(d.get("check_type") or "").strip().upper()
                d["check_type_label"] = CHECK_TYPE_LABELS.get(code, code)
                day = str(d.get("check_date") or d.get("created_at") or "")[:10]
                try: cyc_key = round(float(d.get("cycle") or 0), 6)
                except Exception: cyc_key = 0.0
                try: cum_key = round(float(d.get("cumulative") or 0), 6)
                except Exception: cum_key = 0.0
                d["process_type"] = process_map.get((day, str(d.get("mold_code") or "").strip().upper(), code, cyc_key, cum_key), "수동")
                d["assignee"] = d.get("created_by") or ""
                rows.append(d)
            return {"configured": True, "rows": rows, "check_type_labels": dict(CHECK_TYPE_LABELS)}
        return self.app.run_db(work)

    # ---------------------------------------------------------------
    # complete maintenance
    # ---------------------------------------------------------------
    def complete(self, body, user):
        self._need_config()
        rid = self._rid(body.get("rid"))
        sm, hm = self.cfg["schedule_cols"], self.cfg["history_cols"]
        date_text = str(body.get("check_date") or "").strip()
        try:
            check_dt = dt.datetime.strptime(date_text[:16], "%Y-%m-%d %H:%M") if len(date_text) >= 16 \
                else dt.datetime.strptime(date_text[:10], "%Y-%m-%d")
        except Exception:
            check_dt = dt.datetime.now()
        desc = str(body.get("description") or "").strip()
        uname = str(user or "").split("(실행", 1)[0].strip()[:50] or "WEB"

        def work(conn):
            cur = conn.cursor()
            sched_table = self._table(self.cfg["schedule_table"])
            hist_table = self._table(self.cfg["history_table"])

            # Lock selected maintenance rule while completing it.
            cur.execute(f"SELECT T.* FROM {sched_table} T WHERE ROWID=CHARTOROWID(:rid) FOR UPDATE", rid=rid)
            row = cur.fetchone()
            if row is None:
                raise self.UserError("점검항목을 찾지 못했습니다. 다시 조회하세요.")
            names = [d[0] for d in cur.description]
            src = dict(zip(names, row))

            def sv(key):
                c = sm.get(key)
                return src.get(c) if c else None

            cycle = self._num(sv("cycle"))
            cumulative = self._num(sv("cumulative"))
            if cycle <= 0:
                raise self.UserError("점검주기가 0이어서 완료 처리할 수 없습니다.")

            # Build history row from semantic mapping.
            vals = {}
            semantic_values = {
                "mold_code": sv("mold_code"),
                "mold_name": sv("mold_name"),
                "check_type": sv("check_type"),
                "cycle": sv("cycle"),
                "check_date": check_dt,
                "cumulative": sv("cumulative"),
                "description": desc or sv("description") or "웹 자주보전 점검완료",
                "approval": sv("approval"),
                "org_id": sv("org_id"),
                "created_at": dt.datetime.now(),
                "created_by": uname,
                "updated_at": dt.datetime.now(),
                "updated_by": uname,
            }
            for key, val in semantic_values.items():
                c = hm.get(key)
                if c and val is not None:
                    vals[c] = val

            # Copy same-named schedule columns to history as a safety net
            # (organization/company/site codes etc. often have the same name).
            hcols = {x["name"] for x in self._schema_columns(conn, self.cfg["history_table"])}
            for c, v in src.items():
                if c in hcols and c not in vals and v is not None:
                    vals[c] = v

            if not vals:
                raise self.UserError("점검이력에 저장할 컬럼 매핑이 없습니다.")

            cols = list(vals)
            binds = {f"b{i}": vals[c] for i, c in enumerate(cols)}
            sql = (f"INSERT INTO {hist_table} ({', '.join(cols)}) VALUES ("
                   + ", ".join(f":b{i}" for i in range(len(cols))) + ")")
            cur.execute(sql, binds)

            # Reset cumulative shots and update last check date in the same transaction.
            sets = [f"{sm['cumulative']}=0"]
            ub = {"rid": rid}
            if sm.get("check_date"):
                sets.append(f"{sm['check_date']}=:check_dt")
                ub["check_dt"] = check_dt
            if sm.get("updated_at"):
                sets.append(f"{sm['updated_at']}=SYSDATE")
            if sm.get("updated_by"):
                sets.append(f"{sm['updated_by']}=:upd_user")
                ub["upd_user"] = uname
            cur.execute(f"UPDATE {sched_table} SET {', '.join(sets)} WHERE ROWID=CHARTOROWID(:rid)", ub)
            if cur.rowcount != 1:
                raise self.UserError("점검이력은 만들었지만 주기 테이블 갱신 대상을 찾지 못했습니다.")

            conn.commit()
            return {
                "ok": True,
                "mold_code": self.core.show(sv("mold_code")),
                "mold_name": self.core.show(sv("mold_name")),
                "check_type": self.core.show(sv("check_type")),
                "check_type_label": CHECK_TYPE_LABELS.get(str(sv("check_type") or "").strip().upper(),
                                                          self.core.show(sv("check_type"))),
                "cycle": cycle,
                "before_cumulative": cumulative,
                "check_date": check_dt.strftime("%Y-%m-%d %H:%M"),
            }

        try:
            out = self.app.run_db(work)
        except Exception:
            # app.run_db closes connection. Oracle rolls back uncommitted work on close.
            raise

        key = self._assignment_key(out.get("mold_code"), out.get("check_type"), out.get("cycle"))
        assignee = ""
        try:
            with self.lock:
                data = self._load_assignments()
                rec = data.pop(key, None) or {}
                assignee = rec.get("assignee") or ""
                self._save_assignments(data)
                pend = self._load_pending()
                if key in pend:
                    pend.pop(key, None)
                    self._save_pending(pend)
        except Exception:
            pass
        cyc = self._num(out.get("cycle")); cum = self._num(out.get("before_cumulative")); pct = (cum/cyc*100.0) if cyc>0 else 0
        self._append_audit(actor=uname, process_type="점검완료", mold_code=out.get("mold_code"), mold_name=out.get("mold_name"),
                           check_type=out.get("check_type"), cycle=out.get("cycle"), cumulative=out.get("before_cumulative"), progress=round(pct,1),
                           assignee=assignee or uname, before=f"누적타발={self.core.show(out.get('before_cumulative'))}", after="누적타발=0",
                           description=desc or "자주보전 점검완료")
        return out
